# AI-Powered Interview Bot

6-hour hackathon build. Frontend (React) + Backend (Node/Express) + local
Ollama (`qwen3:8b`) for all interview reasoning, browser-native voice, and
client-side attention monitoring.

See `progress.md` for exactly what's implemented per milestone and every
implementation choice made where the problem statement was ambiguous.

## Prerequisites

- Node.js 18+ and npm
- [Ollama](https://ollama.com) installed and running locally, with the model already pulled:
  ```
  ollama pull qwen3:8b
  ollama serve   # usually already running as a background service
  ```
- Chrome or Edge recommended (for the Web Speech API — see Milestone 4 note in `progress.md`).
- Optional: a [Supabase](https://supabase.com) project if you want persistence
  (otherwise everything runs fine in-memory).

## 1. Backend setup

```bash
cd backend
npm install
cp .env.example .env
# edit .env if your Ollama runs elsewhere, or to add Supabase credentials
npm start
```

This starts the API on `http://localhost:5000`. Check it's talking to Ollama:

```bash
curl http://localhost:5000/api/health
```

You should see `"ollama": { "ok": true, "models": ["qwen3:8b", ...] }`.

### Optional: enable Supabase persistence

1. Create a Supabase project.
2. Run `backend/src/supabase/schema.sql` in the Supabase SQL editor.
3. Put your project URL and service-role key into `backend/.env`
   (`SUPABASE_URL`, `SUPABASE_SERVICE_KEY`).
4. Restart the backend. `/api/health` will report `"supabaseConfigured": true`.

## 2. Frontend setup

```bash
cd frontend
npm install
cp .env.example .env   # only needed if backend isn't on localhost:5000
npm run dev
```

Open the printed URL (typically `http://localhost:5173`).

## 3. Using the app

1. **Start screen**: pick a target role, upload a resume (pdf/docx/txt) or paste resume text.
2. **Interview screen**: the question is read aloud automatically. Click "Start speaking"
   to answer by voice (or just type in the box). Submit each answer to get the next,
   adaptively generated question. The **Integrity Console** on the right runs live,
   client-side monitoring — face presence, tab focus, and (in **Strict mode**) fullscreen
   + a devtools heuristic — and logs neutral, timestamped observations. It never blocks or
   judges you, just records what happened for a human reviewer. Use the toggle in the
   header to switch between dark (neon HUD) and light themes; your choice is remembered.
3. **Suspense screen**: after the last answer, the candidate sees a confirmation screen
   only — no score, no report. The evaluation is generated on the backend right away, but
   it's deliberately withheld from the candidate.
4. **HR / Admin Access**: click the "HR / Admin Access" button (suspense screen, report
   screen, or footer) and enter the passkey set in `backend/.env` as `HR_ACCESS_KEY` (a
   demo default is used — and logged at backend startup — if you leave it blank). This
   unlocks the **Report screen**: strengths, gaps, technical evaluation, communication
   notes, an overall recommendation, and the full integrity/attention log — with a clear
   disclaimer that this supports, not replaces, a human decision.
   This is a shared-passkey gate suited to a hackathon demo (rate-limited, checked
   server-side) — not a full multi-user auth system.

## How the backend was tested

Because Ollama itself can't run inside the environment this was built in, the full
`/start → /answer → /integrity-event → /finish` flow was tested end-to-end against a
minimal mock server that mimics Ollama's `/api/generate` and `/api/tags` endpoints —
i.e. every line of real backend code (JSON-mode parsing, session state, adaptive question
selection, integrity event logging, Supabase no-op fallback) ran and was verified; only the
model's "brain" was swapped for a stub. Point `OLLAMA_URL` at your real local Ollama and it
works the same way, with real model reasoning instead of the stub's canned answers.

The frontend was verified with `npm run build` (clean production build, no errors).
Voice and camera features depend on browser APIs and hardware permissions that can only
be exercised in an actual browser session on your machine — test those live after `npm run dev`.

## Project structure

```
backend/
  src/
    server.js              Express app entrypoint, health check
    routes/interview.js    /start, /answer, /finish, /integrity-event
    services/ollama.js     Ollama client (JSON mode + robust parsing)
    services/prompts.js    All prompt templates (tune here)
    services/sessionStore.js  In-memory interview session state
    services/supabase.js   Optional persistence (safe no-op if unconfigured)
    services/resumeParser.js  pdf/docx/txt text extraction
    supabase/schema.sql    Table definitions for Milestone 6
frontend/
  src/
    App.jsx                Screen routing (start → interview → report)
    api.js                 Backend API client
    hooks/useSpeech.js      Web Speech API STT/TTS wrapper (Milestone 4)
    components/
      StartScreen.jsx       Resume upload + role selection
      InterviewScreen.jsx    Live interview loop
      CameraMonitor.jsx      face-api.js attention observation (Milestone 5)
      ReportScreen.jsx       Final report display
  public/models/            Bundled face-api.js tiny face detector weights
progress.md                 Milestone-by-milestone status
```
