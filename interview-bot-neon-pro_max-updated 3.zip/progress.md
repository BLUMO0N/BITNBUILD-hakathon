# Progress

## Milestone 1 — Backend + Ollama connection (`POST /api/interview/start`) — ✅ DONE
- Express server (`backend/src/server.js`) with health check at `/api/health`.
- `POST /api/interview/start` accepts a resume (file upload: pdf/docx/txt, or pasted text)
  and a target role, calls Ollama (`qwen3:8b`, JSON mode) to extract a candidate profile
  and generate the first personalized question.
- Tested end-to-end against a mock Ollama server (real network calls, real JSON parsing,
  real session creation) — see "How it was tested" in the root README.

## Milestone 2 — Adaptive loop (`POST /api/interview/answer`) — ✅ DONE
- Evaluates the candidate's answer (score, strengths, weaknesses).
- Generates the next question and difficulty based on performance so far.
- Signals `isInterviewComplete` once `MAX_QUESTIONS` (default 5, configurable via `.env`) is reached.
- Tested end-to-end (start → answer → next question loop).

## Milestone 3 — Final report (`POST /api/interview/finish`) — ✅ DONE
- Generates a structured report: overall score, strengths, gaps, technical evaluation,
  communication observations, summary, recommendation, and an explicit disclaimer that
  this supports (not replaces) human hiring judgment.
- Tested end-to-end.

## Milestone 4 — Voice interaction — ✅ DONE (implementation choice noted)
- Spoken interview via the browser's Web Speech API (SpeechRecognition for STT,
  SpeechSynthesis for TTS) instead of self-hosted Whisper/Piper — zero setup, works
  instantly in Chrome/Edge, same user-facing capability. See `frontend/src/hooks/useSpeech.js`
  for the reasoning; swapping in real Whisper/Piper later only touches that one file.
- Automatic fallback to typed answers if the browser doesn't support the Web Speech API,
  or if the user just prefers to type.

## Milestone 5 — Camera / attention observation — ✅ DONE
- `frontend/src/components/CameraMonitor.jsx` uses face-api.js's tiny face detector
  (a small pretrained model, bundled in `frontend/public/models`, runs entirely
  client-side — nothing is uploaded).
- Logs only neutral, timestamped observations: `face_not_detected`, `multiple_faces`,
  `attention_observation`, `camera_unavailable`. Never labels anything as "cheating."
- `POST /api/interview/integrity-event` records these; they're surfaced transparently
  on the final report screen, tested end-to-end.

## Post-hackathon fixes (see summary below)
- **Speech transcription repetition fixed.** `useSpeech.js`'s onresult handler was
  appending every result (final + interim) onto the existing transcript on every
  event, causing repeated/duplicated words in continuous mode. Now rebuilds the
  transcript from `event.results` each time and keeps final vs. interim text as
  separate state, so nothing gets double-counted.
- **Camera monitoring upgraded.** `CameraMonitor.jsx` now uses `detectAllFaces()`
  (was `detectSingleFace()`, which could never see a second person), requires a
  short run of consecutive confirming checks before logging anything (was
  effectively single-frame-triggered for "looking away"), and adds a cooldown so a
  persistent or flickering condition can't spam repeated alerts. `looking_away` was
  renamed to `attention_observation` and a new `multiple_faces` observation was
  added, matching the neutral-observation framing above. The detection loop is
  self-scheduling (setTimeout chained after each check) instead of a bare
  `setInterval`, so slow checks can't overlap and pile up.

## Milestone 6 — Supabase persistence + full connection — ✅ DONE (persistence optional)
- `backend/src/supabase/schema.sql` defines `sessions`, `questions_answers`, `reports`,
  `integrity_events` tables.
- `backend/src/services/supabase.js` writes to these tables whenever `SUPABASE_URL` and
  `SUPABASE_SERVICE_KEY` are set in `.env`. If they're not set, every call is a safe
  no-op — the whole app (Milestones 1–5) works fully in-memory with zero Supabase setup,
  exactly per the "don't build unnecessary complexity" instruction.
- Frontend and backend are fully wired end-to-end (see root README "Run it" section).

## Milestone 7 — Next-level integrity monitoring + UI/UX overhaul — ✅ DONE
- **New detection signals** (`frontend/src/hooks/useIntegrityGuard.js`), all following the
  same "neutral observation, never a verdict, never blocks the candidate" rule as the
  existing vision checks:
  - `tab_hidden` — tab switched or window lost focus (`visibilitychange` + `blur`).
  - `fullscreen_exited` — candidate left fullscreen (only armed in Strict mode, since
    fullscreen itself is opt-in).
  - `paste_detected` — text pasted into the live answer box, with a rough word count.
  - `devtools_suspected` — a deliberately low-confidence heuristic (outer vs. inner
    window size delta), explicitly labeled "suspected" and only armed in Strict mode
    because it has real false positives.
  - All four share the same consecutive-check/cooldown discipline as the camera checks
    (`EVENT_COOLDOWN_MS`) so nothing can spam the log.
- **Strict mode** toggle in the new Integrity Console: arms fullscreen enforcement and
  the devtools heuristic, and requests/exits fullscreen on toggle.
- **Unified Integrity Console** (`components/IntegrityConsole.jsx`): live status chips
  (Vision / Tab focus / Fullscreen), a severity-tagged running event feed, and
  high/medium/low counts — all clearly framed as observations for a human reviewer, not
  a score. `CameraMonitor.jsx` now reports its status/error up via `onStatusChange` /
  `onErrorChange` instead of rendering its own status text, so the console can show one
  consistent picture.
- **Shared event metadata** (`frontend/src/integrityEvents.js`) — label/severity/icon per
  event type, used by both the live console and the final report so they stay consistent.
- **Report screen** now shows a full integrity summary (severity counts + the full
  timestamped list), not just a raw list.
- **UI/UX rewrite**: full neon red/green/blue accent system on a dark HUD-style theme
  (animated background grid + glow, Orbitron/Rajdhani fonts), with a persisted
  **light/dark theme toggle** (`hooks/useTheme.js`, top-right switch) that swaps the
  whole app to a bright high-contrast palette via CSS variables — no visual logic is
  duplicated between themes, only the variable values change.
- `vite.config.js` now splits `face-api.js` into its own chunk (was one ~800kB bundle,
  now the app code is ~166kB gzip ~53kB and the vision model is a separate ~640kB chunk
  that can load in parallel / cache independently).
- Verified with `npm install && npm run build` — clean production build, no errors.

## Milestone 8 — HR-gated results + polished background — ✅ DONE
- **Result suspense**: the candidate's `/finish` call no longer returns the report or
  integrity log — it only confirms submission (`{ ok: true, status: "submitted" }`).
  The candidate lands on a new `SuspenseScreen.jsx` ("Thanks — that's a wrap") with a
  checklist and an honest explanation that a human (HR) reviews the result, not the
  candidate.
- **HR/admin passkey gate**: a new `POST /api/interview/report` endpoint
  (`backend/src/routes/interview.js`) returns the report + integrity log only if a
  passkey matches `HR_ACCESS_KEY` (`backend/.env`, see `services/hrAccess.js`) — checked
  **server-side**, never compared in the browser bundle. Includes basic per-IP rate
  limiting (5 attempts, 1-minute lockout) against guessing. If `HR_ACCESS_KEY` is unset,
  a demo default is used and loudly logged at backend startup — this is a shared-secret
  gate appropriate for a hackathon prototype, not real multi-user auth; swap in proper
  auth (e.g. Supabase auth + a role column) for production use.
- Frontend: `HRAccessGate.jsx` (passkey modal) + `api.js`'s `submitForReview` /
  `fetchHrReport`. The "HR / Admin Access" entry point appears on the suspense and
  report screens and in the footer once a session has been submitted.
- **Key Features section** added to the start screen (profile-aware questioning,
  conversational/adaptive interviewing, integrity monitoring) matching the product's
  stated feature set, reinforcing that integrity observations go to recruiters, not
  candidates.
- **Background polish**: added `FloatingOrbs.jsx` (drifting glow shapes/rings/diamonds
  across the neon palette) plus a fourth accent-colored glow blob, on top of the
  existing grid + glow background, with `prefers-reduced-motion` respected.
- Verified with `npm install && npm run build` (frontend) and `node --check` on all
  touched backend files.

## Milestone 9 — HR usability, strict eye contact, anti-copy, DSA, performance — ✅ DONE
- **HR passkey**: default/demo `HR_ACCESS_KEY` is now `1234` (`backend/.env.example`,
  `services/hrAccess.js`). Still overridable via `.env` for a real deployment.
- **Strict, real-time eye-contact enforcement**: `CameraMonitor.jsx` now emits a live
  `onAttentionChange({ looking, reason })` signal (no cooldown, reacts in ~3s) alongside
  its existing cooldown-limited logged observations. `InterviewScreen.jsx` surfaces this
  as a pulsing on-screen warning ("please look at the camera/screen") the instant the
  candidate looks away, and clears it the instant they look back - separate from, and in
  addition to, the neutral timestamped log HR sees afterward.
- **Anti-copy hardening**: the question text and interview card are `user-select: none`
  with `copy`/`cut` event blocking (backed up at the CSS layer), right-click is disabled
  outside the answer box, and common devtools/view-source/save-page shortcuts
  (F12, Ctrl/Cmd+Shift+I/J/C, Ctrl/Cmd+U/S) are intercepted - each attempt is logged as a
  neutral `copy_blocked` / `devtools_shortcut_blocked` observation for HR, same as every
  other integrity signal. The answer textarea is explicitly exempted throughout so typing,
  editing, and pasting a genuine answer is unaffected.
- **Replay control**: a "🔁 Replay question" button now sits next to the mic button,
  disabled while the question is being read aloud (or while recording) and enabling the
  instant TTS finishes - so a candidate can't replay mid-sentence or talk over the AI.
- **Guaranteed DSA question**: for technical/software roles (`prompts.js:isTechnicalRole`),
  the adaptive loop now deterministically injects one Data Structures & Algorithms question
  (linked lists, arrays, graphs, sorting, complexity, etc. - phrased for a spoken interview,
  no live code editor) roughly two-thirds through the interview via `pickDsaQuestion()`,
  on top of nudging the model's own prompts to include DSA questions for such roles.
- **Fixed post-submit lag**: the multi-second delay after submitting an answer was mostly
  qwen3's internal `<think>` reasoning trace running before the JSON answer even started.
  `ollama.js` now sends `think: false` (skips the reasoning phase for hybrid-reasoning
  models), caps `num_predict` so generation can't run long, and sets `keep_alive: "30m"`
  so the model stays resident between requests instead of reloading. A 90s client-side
  timeout also fails fast with a clear error if Ollama itself stalls, instead of hanging.

## Milestone 10 — HR passkey hard-locked to 1234 — ✅ DONE
- `getHrAccessKey()` in `backend/src/services/hrAccess.js` now returns `"1234"`
  unconditionally, ignoring `process.env.HR_ACCESS_KEY` entirely - so the passkey always
  works the same way regardless of what a local `.env` file happens to contain (a stale
  value from an earlier run, a typo, etc.). The startup log always prints the active
  passkey plainly. To make it configurable via `.env` again later, see the comment in
  `hrAccess.js`.

## What's left / nice-to-haves if there's time left in the hackathon
- Add a mananged chunk split for the frontend build (face-api.js pushes the bundle over
  Vite's default 500kB warning threshold — cosmetic only, not a functional issue).
- Add automated tests (currently verified via manual + mock-Ollama end-to-end curl tests).
- Optional: swap Web Speech API for real local Whisper/Piper if the judges specifically
  require fully offline/on-device audio processing.
