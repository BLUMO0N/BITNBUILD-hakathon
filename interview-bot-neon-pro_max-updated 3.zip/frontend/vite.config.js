import { defineConfig } from "vite";
import react from "@vitejs/plugin-react";

export default defineConfig({
  plugins: [react()],
  server: {
    port: 5173,
  },
  build: {
    rollupOptions: {
      output: {
        // face-api.js (the vision model runtime) is the bulk of the bundle
        // and rarely changes - split it into its own chunk so app-code
        // edits don't force users to re-download it, and so it can load
        // in parallel with the rest of the app.
        manualChunks: {
          "face-api": ["face-api.js"],
        },
      },
    },
  },
});
