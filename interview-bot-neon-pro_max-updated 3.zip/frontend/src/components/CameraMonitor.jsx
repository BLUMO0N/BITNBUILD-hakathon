// components/CameraMonitor.jsx
//
// MILESTONE 5 — lightweight, local, pretrained vision for attention
// observation. Uses face-api.js's tiny face detector (a small pretrained
// model, ~190KB, bundled in /public/models — runs fully client-side,
// nothing is uploaded anywhere).
//
// IMPORTANT (per the spec): this only ever RECORDS neutral observations
// ("face_not_detected", "multiple_faces", "attention_observation") with
// timestamps. It never claims "cheating detected" and never makes a
// pass/fail judgment — that framing is intentional and should not be
// changed.
//
// --- FIX NOTES -----------------------------------------------------------
// - detectSingleFace() -> detectAllFaces(): the old call physically
//   cannot report more than one face, so a second person in frame was
//   invisible to it. Switched to detectAllFaces() and now branch on how
//   many boxes come back (0 / 1 / >1).
// - This polls the video at a fixed cadence rather than tracking every
//   rendered video frame - it is NOT 60fps real-time tracking, and the
//   status text below doesn't claim otherwise. Detection uses a
//   self-scheduling loop (setTimeout chained after each check finishes)
//   instead of a bare setInterval, so a slow detection pass can never
//   overlap with the next one and pile up work on slower machines.
// - "Looking away" used to be judged from a single frame's face-center
//   offset, which is noisy (one bad frame from blinking, head tilt, etc.
//   could fire it). Off-center is now tracked over several consecutive
//   checks before it's treated as an observation, and only the
//   horizontal offset persisting is treated as a possible attention
//   shift - renamed to the neutral "attention_observation".
// - Every observation type now requires a short run of consecutive
//   confirming checks (not one or two noisy frames) AND respects a
//   cooldown before the same type of observation can fire again, so a
//   flickering condition can't spam repeated alerts.

import { useEffect, useRef, useState } from "react";
import * as faceapi from "face-api.js";

// Poll roughly twice a second. The tiny face detector is small/fast
// enough that this stays cheap, while still being responsive enough to
// build up a few consecutive confirming checks quickly.
const DETECTION_INTERVAL_MS = 1500;
// Shrinking the detector's internal input size keeps each check fast and
// lightweight (trade-off: slightly less precise boxes, which is fine -
// we only need "is there a face / how many / roughly where").
const DETECTOR_OPTIONS = new faceapi.TinyFaceDetectorOptions({
  inputSize: 224,
  scoreThreshold: 0.5,
});

// How many consecutive checks must agree before we treat a condition as
// real (not one or two noisy frames).
const CONSECUTIVE_CHECKS_THRESHOLD = 3;
// Once an observation type fires, don't fire that same type again for
// this long, even if the condition keeps being met.
const ALERT_COOLDOWN_MS = 20000;
// Face-center offset from frame-center (as a fraction of frame width)
// beyond which a single face is considered off-center.
const OFF_CENTER_X_THRESHOLD = 0.28;
// STRICT EYE-CONTACT MODE: a much shorter streak used only to drive the
// live on-screen "please look at the camera/screen" nudge shown to the
// candidate in real time. Deliberately separate from
// CONSECUTIVE_CHECKS_THRESHOLD/ALERT_COOLDOWN_MS above, which still
// govern the neutral, cooldown-limited log entries sent to HR - the live
// nudge has no cooldown (it should clear the instant the candidate looks
// back) and reacts faster since it's just a UI cue, not a logged claim.
const LOOK_AWAY_WARNING_STREAK = 2;

export default function CameraMonitor({ enabled, onEvent, onStatusChange, onErrorChange, onAttentionChange }) {
  const videoRef = useRef(null);
  const streamRef = useRef(null);
  const timeoutRef = useRef(null);
  const runningRef = useRef(false);

  const noFaceStreakRef = useRef(0);
  const multiFaceStreakRef = useRef(0);
  const offCenterStreakRef = useRef(0);
  const lastAlertAtRef = useRef({
    face_not_detected: 0,
    multiple_faces: 0,
    attention_observation: 0,
  });

  const [modelsReady, setModelsReady] = useState(false);
  const [cameraError, setCameraError] = useState(null);
  // Neutral, user-facing status only - never a verdict.
  const [status, setStatus] = useState({
    kind: "info", // "info" | "ok" | "notice"
    text: "Loading vision model...",
  });

  // Let a parent HUD (IntegrityConsole) mirror this component's status
  // without owning the detection logic itself.
  useEffect(() => {
    onStatusChange?.(status);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [status]);

  useEffect(() => {
    onErrorChange?.(cameraError);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [cameraError]);

  // Load models once. If this fails, camera monitoring simply stays off
  // - the interview itself never depends on it.
  useEffect(() => {
    let cancelled = false;
    faceapi.nets.tinyFaceDetector
      .loadFromUri("/models")
      .then(() => {
        if (!cancelled) {
          setModelsReady(true);
          setStatus({ kind: "ok", text: "Starting attention monitoring..." });
        }
      })
      .catch((err) => {
        console.warn("Vision models failed to load:", err.message);
        if (!cancelled) {
          setModelsReady(false);
          setStatus({
            kind: "notice",
            text: "Attention monitoring unavailable (model failed to load). Interview continues normally.",
          });
        }
      });
    return () => {
      cancelled = true;
    };
  }, []);

  // Start/stop camera based on `enabled`.
  useEffect(() => {
    if (!enabled) {
      stopCamera();
      onAttentionChange?.({ looking: true, reason: null }); // can't observe - don't hold a stale warning up
      return;
    }

    let cancelled = false;

    async function start() {
      try {
        const stream = await navigator.mediaDevices.getUserMedia({ video: true });
        if (cancelled) {
          stream.getTracks().forEach((t) => t.stop());
          return;
        }
        streamRef.current = stream;
        if (videoRef.current) {
          videoRef.current.srcObject = stream;
        }
        setCameraError(null);
      } catch (err) {
        setCameraError(
          "Camera unavailable or permission denied. Continuing in text-only mode."
        );
        onEvent({ type: "camera_unavailable", detail: err.message });
      }
    }

    start();

    return () => {
      cancelled = true;
      stopCamera();
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [enabled]);

  // Detection loop: only once models are ready and the camera is on.
  // Uses a self-scheduling setTimeout (waits for each check to finish
  // before scheduling the next) instead of setInterval, so checks never
  // overlap/pile up if a device is briefly slow - this is what keeps it
  // lightweight rather than a fixed-rate timer alone.
  useEffect(() => {
    if (!enabled || !modelsReady || cameraError) return;

    runningRef.current = true;
    resetStreaks();

    async function tick() {
      if (!runningRef.current) return;
      const video = videoRef.current;

      if (video && video.readyState >= 2) {
        try {
          const detections = await faceapi.detectAllFaces(video, DETECTOR_OPTIONS);
          handleDetections(detections, video);
        } catch (err) {
          // Never let a detection hiccup break the interview - just skip
          // this check.
          console.warn("Face detection check failed:", err.message);
        }
      }

      if (runningRef.current) {
        timeoutRef.current = setTimeout(tick, DETECTION_INTERVAL_MS);
      }
    }

    timeoutRef.current = setTimeout(tick, DETECTION_INTERVAL_MS);

    return () => {
      runningRef.current = false;
      if (timeoutRef.current) clearTimeout(timeoutRef.current);
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [enabled, modelsReady, cameraError]);

  function resetStreaks() {
    noFaceStreakRef.current = 0;
    multiFaceStreakRef.current = 0;
    offCenterStreakRef.current = 0;
  }

  // Fires `onEvent` once a streak crosses the consecutive-checks
  // threshold, but only if that observation type isn't still in its
  // cooldown window - this is what stops a persistent condition (or a
  // flickering one) from spamming repeated alerts.
  function maybeFire(type, detail) {
    const now = Date.now();
    const last = lastAlertAtRef.current[type] || 0;
    if (now - last >= ALERT_COOLDOWN_MS) {
      onEvent({ type, detail });
      lastAlertAtRef.current[type] = now;
    }
  }

  function handleDetections(detections, video) {
    const count = detections ? detections.length : 0;

    if (count === 0) {
      noFaceStreakRef.current += 1;
      multiFaceStreakRef.current = 0;
      offCenterStreakRef.current = 0;
      setStatus({ kind: "notice", text: "No face detected" });

      if (noFaceStreakRef.current >= LOOK_AWAY_WARNING_STREAK) {
        onAttentionChange?.({ looking: false, reason: "no_face" });
      }

      if (noFaceStreakRef.current >= CONSECUTIVE_CHECKS_THRESHOLD) {
        maybeFire(
          "face_not_detected",
          `No face detected for ~${Math.round(
            (noFaceStreakRef.current * DETECTION_INTERVAL_MS) / 1000
          )}s`
        );
        noFaceStreakRef.current = 0;
      }
      return;
    }

    if (count > 1) {
      multiFaceStreakRef.current += 1;
      noFaceStreakRef.current = 0;
      offCenterStreakRef.current = 0;
      setStatus({ kind: "notice", text: `${count} faces in frame` });
      onAttentionChange?.({ looking: false, reason: "multiple_faces" });

      if (multiFaceStreakRef.current >= CONSECUTIVE_CHECKS_THRESHOLD) {
        maybeFire("multiple_faces", `${count} faces detected in frame at the same time`);
        multiFaceStreakRef.current = 0;
      }
      return;
    }

    // Exactly one face - the expected case.
    noFaceStreakRef.current = 0;
    multiFaceStreakRef.current = 0;

    const box = detections[0].box;
    const faceCenterX = box.x + box.width / 2;
    const frameWidth = video.videoWidth || 640;
    const offset = (faceCenterX - frameWidth / 2) / frameWidth;

    if (Math.abs(offset) > OFF_CENTER_X_THRESHOLD) {
      offCenterStreakRef.current += 1;
      setStatus({ kind: "ok", text: "Face detected (off-center)" });

      if (offCenterStreakRef.current >= LOOK_AWAY_WARNING_STREAK) {
        onAttentionChange?.({ looking: false, reason: "off_center" });
      }

      if (offCenterStreakRef.current >= CONSECUTIVE_CHECKS_THRESHOLD) {
        maybeFire(
          "attention_observation",
          `Face has been off-center (${offset > 0 ? "right" : "left"}) for ~${Math.round(
            (offCenterStreakRef.current * DETECTION_INTERVAL_MS) / 1000
          )}s`
        );
        offCenterStreakRef.current = 0;
      }
    } else {
      offCenterStreakRef.current = 0;
      // Looking squarely at the camera/screen - clear any live warning
      // immediately. Unlike the logged observations above, this nudge
      // has no cooldown: it should track the candidate's real-time state.
      onAttentionChange?.({ looking: true, reason: null });
      setStatus({ kind: "ok", text: "Face detected" });
    }
  }

  function stopCamera() {
    runningRef.current = false;
    if (timeoutRef.current) clearTimeout(timeoutRef.current);
    if (streamRef.current) {
      streamRef.current.getTracks().forEach((t) => t.stop());
      streamRef.current = null;
    }
  }

  if (!enabled) return null;

  const statusKind = cameraError ? "notice" : status.kind;

  return (
    <div className="camera-monitor">
      <div className="camera-frame">
        <video ref={videoRef} autoPlay muted playsInline className="camera-preview" />
        <span className="camera-frame-corner tl" />
        <span className="camera-frame-corner tr" />
        <span className="camera-frame-corner bl" />
        <span className="camera-frame-corner br" />
        <span className={`camera-live-dot camera-live-dot-${statusKind}`} />
      </div>
    </div>
  );
}
