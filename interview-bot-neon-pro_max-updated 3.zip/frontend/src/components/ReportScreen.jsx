// components/ReportScreen.jsx — final evaluation report.

import { eventMeta } from "../integrityEvents.js";

export default function ReportScreen({ report, integrityEvents, onRestart }) {
  if (!report) return null;

  const events = integrityEvents || [];
  const counts = { high: 0, medium: 0, low: 0 };
  events.forEach((e) => {
    const meta = eventMeta(e.type);
    counts[meta.severity] = (counts[meta.severity] || 0) + 1;
  });

  const scoreOutOf10 = Number(report.overallScore) || 0;
  const scorePct = Math.max(0, Math.min(100, (scoreOutOf10 / 10) * 100));

  return (
    <div className="card report-card">
      <div className="eyebrow">SESSION COMPLETE</div>
      <h1>Interview Report</h1>

      <div className="score-panel">
        <div
          className="score-ring"
          style={{ "--score-pct": `${scorePct}%` }}
          role="img"
          aria-label={`Overall score ${scoreOutOf10} out of 10`}
        >
          <div className="score-ring-inner">
            <span className="score-value">{scoreOutOf10}</span>
            <span className="score-max">/10</span>
          </div>
        </div>
        <div className="recommendation">{report.recommendation}</div>
      </div>

      <section>
        <h3>Strengths</h3>
        <ul>
          {report.strengths?.map((s, i) => (
            <li key={i}>{s}</li>
          ))}
        </ul>
      </section>

      <section>
        <h3>Gaps / Areas to Improve</h3>
        <ul>
          {report.gaps?.map((g, i) => (
            <li key={i}>{g}</li>
          ))}
        </ul>
      </section>

      <section>
        <h3>Technical Evaluation</h3>
        <p>{report.technicalEvaluation}</p>
      </section>

      <section>
        <h3>Communication Observations</h3>
        <p>{report.communicationObservations}</p>
      </section>

      <section>
        <h3>Summary</h3>
        <p>{report.summary}</p>
      </section>

      <section>
        <h3>Integrity Monitoring Summary</h3>
        <p className="notice">
          These are raw, timestamped observations only — not proof of any wrongdoing. A
          human reviewer should always make the final call.
        </p>

        <div className="integrity-counts report-integrity-counts">
          <span className="count-pill count-high">{counts.high} high</span>
          <span className="count-pill count-medium">{counts.medium} medium</span>
          <span className="count-pill count-low">{counts.low} low</span>
          <span className="count-total">{events.length} total observation{events.length === 1 ? "" : "s"}</span>
        </div>

        {events.length > 0 ? (
          <ul className="report-integrity-list">
            {events.map((e, i) => {
              const meta = eventMeta(e.type);
              return (
                <li key={i} className={`severity-${meta.severity}`}>
                  <span className="integrity-feed-icon">{meta.icon}</span>
                  <strong>{meta.label}</strong> — {e.detail}{" "}
                  <span className="timestamp">
                    ({new Date(e.timestamp).toLocaleTimeString()})
                  </span>
                </li>
              );
            })}
          </ul>
        ) : (
          <p className="notice">No integrity observations were logged during this session.</p>
        )}
      </section>

      <div className="disclaimer">{report.disclaimer}</div>

      <button className="primary-btn" onClick={onRestart}>
        Start Another Interview
      </button>
    </div>
  );
}
