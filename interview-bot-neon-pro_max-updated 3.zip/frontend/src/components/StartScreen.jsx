// components/StartScreen.jsx — resume upload + job role selection.

import { useState } from "react";

const ROLE_OPTIONS = [
  "Frontend Engineer",
  "Backend Engineer",
  "Full-Stack Engineer",
  "Data Analyst / ML Engineer",
  "Other",
];

export default function StartScreen({ onStart, loading, error }) {
  const [role, setRole] = useState(ROLE_OPTIONS[0]);
  const [customRole, setCustomRole] = useState("");
  const [resumeText, setResumeText] = useState("");
  const [resumeFile, setResumeFile] = useState(null);

  const effectiveRole = role === "Other" ? customRole.trim() : role;
  const canSubmit = effectiveRole && (resumeText.trim() || resumeFile) && !loading;

  return (
    <div className="card start-card">
      <div className="eyebrow">AI-POWERED · ADAPTIVE · MONITORED</div>
      <h1 className="hero-title">
        Your interview,{" "}
        <span className="neon-text">
          <span className="neon-r">r</span>
          <span className="neon-g">e</span>
          <span className="neon-b">a</span>
          <span className="neon-r">d</span>
          <span className="neon-g">y</span>
        </span>
      </h1>
      <p className="subtitle">
        Upload your resume, pick a target role, and start a personalized, adaptive mock
        interview with live integrity monitoring built in.
      </p>

      <div className="feature-chip-row">
        <span className="feature-chip">🎙 Voice-native</span>
        <span className="feature-chip">🧠 Adaptive questions</span>
        <span className="feature-chip">🛡 Integrity monitoring</span>
      </div>

      <div className="key-features-grid">
        <div className="key-feature-card">
          <span className="key-feature-icon neon-b-glow">🧬</span>
          <h3>Profile-Aware Questioning &amp; Evaluation</h3>
          <p>
            Understands your resume in the context of the target role and generates
            relevant, personalized questions. At the end of the session it produces a
            comprehensive evaluation covering strengths, gaps, and overall suitability.
          </p>
        </div>
        <div className="key-feature-card">
          <span className="key-feature-icon neon-g-glow">💬</span>
          <h3>Conversational &amp; Adaptive Interviewing</h3>
          <p>
            Conducted as a natural spoken conversation, not a static questionnaire — the
            depth and direction adjusts to each response, probing where you show
            strength and adapting where you struggle, closely replicating a real
            interviewer.
          </p>
        </div>
        <div className="key-feature-card">
          <span className="key-feature-icon neon-r-glow">🛡</span>
          <h3>Interview Integrity Monitoring</h3>
          <p>
            Observes attention throughout the session and flags behaviour that may
            indicate external help. These observations are shown transparently to
            recruiters — never to the candidate — building trust in every interview.
          </p>
        </div>
      </div>

      <label className="field-label">Target role</label>
      <select value={role} onChange={(e) => setRole(e.target.value)}>
        {ROLE_OPTIONS.map((r) => (
          <option key={r} value={r}>
            {r}
          </option>
        ))}
      </select>
      {role === "Other" && (
        <input
          type="text"
          placeholder="e.g. DevOps Engineer"
          value={customRole}
          onChange={(e) => setCustomRole(e.target.value)}
        />
      )}

      <label className="field-label">Resume file (.pdf, .docx, .txt)</label>
      <input
        type="file"
        accept=".pdf,.docx,.txt"
        onChange={(e) => setResumeFile(e.target.files?.[0] || null)}
      />

      <label className="field-label">
        Or paste resume text {resumeFile ? "(optional extra context)" : ""}
      </label>
      <textarea
        rows={6}
        placeholder="Paste your resume text here..."
        value={resumeText}
        onChange={(e) => setResumeText(e.target.value)}
      />

      {error && <div className="error-banner">{error}</div>}

      <button
        className="primary-btn"
        disabled={!canSubmit}
        onClick={() => onStart({ role: effectiveRole, resumeText, resumeFile })}
      >
        {loading ? "Starting interview..." : "Start Interview →"}
      </button>

      <p className="start-footnote">
        You'll be able to enable camera monitoring, strict fullscreen mode, and other
        integrity checks once the interview begins — nothing runs before you start.
      </p>
    </div>
  );
}
