// components/FloatingOrbs.jsx
//
// Purely decorative floating shapes drifting across the background, on
// top of the grid + glow layers already in App.jsx. Generated once per
// mount with useMemo so they don't reshuffle on every re-render. This is
// aria-hidden and pointer-events: none (see styles.css) - it never
// intercepts clicks or reads as content to screen readers.

import { useMemo } from "react";

const SHAPES = ["circle", "ring", "diamond"];
const COLORS = ["var(--neon-r)", "var(--neon-g)", "var(--neon-b)", "var(--accent-strong)"];

function makeOrb(seed) {
  // Simple deterministic-ish pseudo-random spread; fine for decoration.
  const rand = (min, max) => min + Math.random() * (max - min);
  return {
    id: seed,
    shape: SHAPES[Math.floor(Math.random() * SHAPES.length)],
    color: COLORS[Math.floor(Math.random() * COLORS.length)],
    size: rand(10, 34),
    left: rand(2, 96),
    top: rand(4, 92),
    duration: rand(14, 30),
    delay: rand(-20, 0),
    drift: rand(30, 90) * (Math.random() > 0.5 ? 1 : -1),
  };
}

export default function FloatingOrbs({ count = 16 }) {
  const orbs = useMemo(() => Array.from({ length: count }, (_, i) => makeOrb(i)), [count]);

  return (
    <div className="floating-orbs" aria-hidden="true">
      {orbs.map((orb) => (
        <span
          key={orb.id}
          className={`floating-orb floating-orb-${orb.shape}`}
          style={{
            "--orb-size": `${orb.size}px`,
            "--orb-left": `${orb.left}%`,
            "--orb-top": `${orb.top}%`,
            "--orb-duration": `${orb.duration}s`,
            "--orb-delay": `${orb.delay}s`,
            "--orb-drift": `${orb.drift}px`,
            "--orb-color": orb.color,
          }}
        />
      ))}
    </div>
  );
}
