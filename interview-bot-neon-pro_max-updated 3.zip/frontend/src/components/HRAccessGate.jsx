// components/HRAccessGate.jsx
//
// Passkey modal for HR/admin. The passkey itself is verified entirely
// server-side (POST /api/interview/report, see backend/src/services/
// hrAccess.js) - this component never knows the real passkey and never
// decides access on its own; it just collects input and shows whatever
// the server says.

import { useState } from "react";

export default function HRAccessGate({ onSubmit, onClose, loading, error }) {
  const [passkey, setPasskey] = useState("");

  function handleSubmit(e) {
    e.preventDefault();
    if (!passkey.trim() || loading) return;
    onSubmit(passkey.trim());
  }

  return (
    <div className="modal-overlay" onClick={onClose}>
      <div className="modal-card" onClick={(e) => e.stopPropagation()}>
        <button className="modal-close" onClick={onClose} aria-label="Close">
          ×
        </button>
        <div className="modal-lock-icon">🔒</div>
        <h2 className="modal-title">HR / Admin Access</h2>
        <p className="modal-subtitle">
          Enter the shared passkey to unlock this candidate's evaluation report and
          integrity log.
        </p>

        <form onSubmit={handleSubmit}>
          <input
            type="password"
            autoFocus
            placeholder="Passkey"
            value={passkey}
            onChange={(e) => setPasskey(e.target.value)}
            className="modal-input"
          />
          {error && <div className="error-banner">{error}</div>}
          <button className="primary-btn" type="submit" disabled={!passkey.trim() || loading}>
            {loading ? "Verifying..." : "Unlock report"}
          </button>
        </form>
      </div>
    </div>
  );
}
