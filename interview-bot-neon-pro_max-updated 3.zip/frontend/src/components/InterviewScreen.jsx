// components/InterviewScreen.jsx — the live interview loop.

import { useEffect, useRef, useState } from "react";
import { useSpeech } from "../hooks/useSpeech.js";
import { useIntegrityGuard } from "../hooks/useIntegrityGuard.js";
import CameraMonitor from "./CameraMonitor.jsx";
import IntegrityConsole from "./IntegrityConsole.jsx";
import { submitAnswer, logIntegrityEvent } from "../api.js";

export default function InterviewScreen({
  sessionId,
  question,
  questionNumber,
  maxQuestions,
  onAnswered,
}) {
  const speech = useSpeech();
  const [manualAnswer, setManualAnswer] = useState("");
  const [submitting, setSubmitting] = useState(false);
  const [error, setError] = useState(null);
  const [cameraOn, setCameraOn] = useState(true);
  const [strict, setStrict] = useState(false);
  const [lastFeedback, setLastFeedback] = useState(null);
  const [cameraStatus, setCameraStatus] = useState(null);
  const [cameraError, setCameraError] = useState(null);
  const [integrityEvents, setIntegrityEvents] = useState([]);
  const [lookingAway, setLookingAway] = useState(false);
  const [lookAwayReason, setLookAwayReason] = useState(null);

  const answerRef = useRef(null);

  const LOOK_AWAY_MESSAGE = {
    no_face: "We can't see your face — please look at the camera/screen.",
    off_center: "Please keep looking at the camera/screen.",
    multiple_faces: "More than one face is visible — please make sure you're alone in frame.",
  };

  function handleIntegrityEvent(event) {
    const withTime = { ...event, timestamp: new Date().toISOString() };
    setIntegrityEvents((prev) => [...prev, withTime]);
    logIntegrityEvent({ sessionId, ...event });
  }

  const guard = useIntegrityGuard({ enabled: true, strict, onEvent: handleIntegrityEvent });

  // Bind paste detection to the live answer textarea (works whether
  // speech or typing is the active input mode).
  useEffect(() => {
    return guard.bindPasteDetection(answerRef.current);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [guard.bindPasteDetection, speech.supported]);

  // ANTI-COPY: it should be impossible to lift the question (or any other
  // interview content) off the screen via copy/cut, and right-click ->
  // "Inspect"/view-source style shortcuts are blocked too. The answer
  // textarea is always explicitly exempted so typing/editing/pasting a
  // genuine answer still works normally - this only stops copying the
  // interview's own content out.
  useEffect(() => {
    function blockCopyCut(e) {
      if (e.target === answerRef.current) return;
      e.preventDefault();
      handleIntegrityEvent({ type: "copy_blocked", detail: "Attempted to copy interview content" });
    }
    function blockShortcuts(e) {
      const key = e.key.toLowerCase();
      const isDevtoolsKey =
        key === "f12" || ((e.ctrlKey || e.metaKey) && e.shiftKey && ["i", "j", "c"].includes(key));
      const isViewSourceOrSaveKey = (e.ctrlKey || e.metaKey) && ["u", "s"].includes(key);
      if (isDevtoolsKey || isViewSourceOrSaveKey) {
        e.preventDefault();
        handleIntegrityEvent({
          type: "devtools_shortcut_blocked",
          detail: `Blocked ${isDevtoolsKey ? "developer tools" : "view-source/save-page"} shortcut`,
        });
      }
    }
    document.addEventListener("copy", blockCopyCut);
    document.addEventListener("cut", blockCopyCut);
    document.addEventListener("keydown", blockShortcuts);
    return () => {
      document.removeEventListener("copy", blockCopyCut);
      document.removeEventListener("cut", blockCopyCut);
      document.removeEventListener("keydown", blockShortcuts);
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  function handleContextMenu(e) {
    // Right-click is disabled everywhere on the interview screen except
    // inside the answer box, where a candidate may legitimately want
    // right-click-paste.
    if (e.target === answerRef.current) return;
    e.preventDefault();
  }

  function handleAttentionChange({ looking, reason }) {
    setLookingAway(!looking);
    setLookAwayReason(looking ? null : reason);
  }

  function handleStrictToggle(next) {
    setStrict(next);
    if (next) guard.requestFullscreen();
    else guard.exitFullscreen();
  }

  // Speak each new question aloud automatically.
  useEffect(() => {
    if (question && speech.supported) {
      speech.speak(question);
    }
    setManualAnswer("");
    speech.setTranscript("");
    setLastFeedback(null);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [question]);

  const answerText = speech.supported ? speech.transcript || manualAnswer : manualAnswer;

  async function handleSubmit() {
    const finalAnswer = answerText.trim();
    if (!finalAnswer) return;
    setSubmitting(true);
    setError(null);
    try {
      const result = await submitAnswer({ sessionId, answer: finalAnswer });
      setLastFeedback(result.lastEvaluation);
      onAnswered(result); // parent decides: advance to next question, or move to report
    } catch (err) {
      setError(err.message);
    } finally {
      setSubmitting(false);
    }
  }

  const progressPct = Math.min(100, Math.round(((questionNumber - 1) / maxQuestions) * 100));

  return (
    <div className="interview-layout" onContextMenu={handleContextMenu}>
      <div className="card interview-card">
        <div className="progress-row">
          <span className="progress-label">
            Question {questionNumber} of {maxQuestions}
          </span>
          <div className="progress-bar">
            <div className="progress-bar-fill" style={{ width: `${progressPct}%` }} />
          </div>
        </div>

        {lookingAway && (
          <div className="eye-contact-warning" role="alert">
            ⚠ {LOOK_AWAY_MESSAGE[lookAwayReason] || "Please look at the camera/screen."}
          </div>
        )}

        <h2
          className="question-text"
          onCopy={(e) => {
            e.preventDefault();
            handleIntegrityEvent({ type: "copy_blocked", detail: "Attempted to copy the interview question" });
          }}
        >
          {question}
        </h2>

        {!speech.supported && (
          <div className="notice">
            Voice not supported in this browser — using text mode. (Try Chrome
            or Edge for spoken interviews.)
          </div>
        )}

        {speech.supported && (
          <div className="voice-controls">
            <button
              className={speech.isListening ? "mic-btn active" : "mic-btn"}
              onClick={speech.isListening ? speech.stopListening : speech.startListening}
              disabled={speech.isSpeaking}
            >
              {speech.isListening ? "◼ Stop recording" : "● Start speaking"}
            </button>
            <button
              className="replay-btn"
              onClick={() => speech.speak(question)}
              disabled={speech.isSpeaking || speech.isListening}
              title={
                speech.isSpeaking
                  ? "Wait for the question to finish reading"
                  : "Replay the question audio"
              }
            >
              🔁 Replay question
            </button>
            {speech.isSpeaking && <span className="speaking-indicator">🔊 Speaking...</span>}
          </div>
        )}

        <label className="field-label">Your answer</label>
        <textarea
          ref={answerRef}
          rows={5}
          placeholder="Speak or type your answer here..."
          value={speech.supported ? speech.transcript : manualAnswer}
          onChange={(e) =>
            speech.supported ? speech.setTranscript(e.target.value) : setManualAnswer(e.target.value)
          }
        />

        {/* Live interim preview only - never written into the answer box
            itself, so it can never duplicate/repeat words once finalized. */}
        {speech.supported && speech.isListening && speech.interimTranscript && (
          <div className="interim-preview">🎤 {speech.interimTranscript}</div>
        )}

        {lastFeedback && (
          <div className="feedback-note">
            Previous answer score: {lastFeedback.score}/10 — {lastFeedback.summary}
          </div>
        )}

        {error && <div className="error-banner">{error}</div>}

        <button
          className="primary-btn"
          disabled={!answerText.trim() || submitting}
          onClick={handleSubmit}
        >
          {submitting ? "Evaluating..." : "Submit Answer"}
        </button>
      </div>

      <aside className="integrity-column">
        <IntegrityConsole
          cameraOn={cameraOn}
          onToggleCamera={setCameraOn}
          cameraStatus={cameraStatus}
          cameraError={cameraError}
          strict={strict}
          onToggleStrict={handleStrictToggle}
          tabFocused={guard.tabFocused}
          isFullscreen={guard.isFullscreen}
          onRequestFullscreen={guard.requestFullscreen}
          events={integrityEvents}
        >
          <CameraMonitor
            enabled={cameraOn}
            onEvent={handleIntegrityEvent}
            onStatusChange={setCameraStatus}
            onErrorChange={setCameraError}
            onAttentionChange={handleAttentionChange}
          />
        </IntegrityConsole>
      </aside>
    </div>
  );
}
