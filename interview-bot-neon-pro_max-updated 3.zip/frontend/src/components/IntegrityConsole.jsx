// components/IntegrityConsole.jsx
//
// The unified "Integrity Monitoring" HUD shown during the interview.
// It does not detect anything itself - CameraMonitor (vision) and
// useIntegrityGuard (tab focus / fullscreen / paste / devtools heuristic)
// own the actual detection logic. This component only visualizes their
// combined output: live status chips + a scrolling, timestamped
// observation log + running counts by severity.
//
// Framing matters here: counts are shown so a human reviewer has
// context, never as a pass/fail score. Nothing here blocks the
// candidate from continuing the interview.

import { eventMeta, SEVERITY_WEIGHT } from "../integrityEvents.js";

export default function IntegrityConsole({
  children, // camera preview, rendered inside the console frame
  cameraOn,
  onToggleCamera,
  cameraStatus,
  cameraError,
  strict,
  onToggleStrict,
  tabFocused,
  isFullscreen,
  onRequestFullscreen,
  events,
}) {
  const recent = events.slice(-8).reverse();
  const counts = { high: 0, medium: 0, low: 0 };
  events.forEach((e) => {
    const meta = eventMeta(e.type);
    counts[meta.severity] = (counts[meta.severity] || 0) + 1;
  });
  const totalWeight =
    counts.high * SEVERITY_WEIGHT.high +
    counts.medium * SEVERITY_WEIGHT.medium +
    counts.low * SEVERITY_WEIGHT.low;

  const visionKind = cameraError ? "notice" : cameraOn ? cameraStatus?.kind || "info" : "off";
  const visionText = cameraError
    ? cameraError
    : cameraOn
    ? cameraStatus?.text || "Initializing..."
    : "Vision monitoring off";

  return (
    <div className="integrity-console">
      <div className="integrity-console-header">
        <span className="integrity-title neon-text">
          <span className="neon-r">I</span>
          <span className="neon-g">N</span>
          <span className="neon-b">T</span>
          <span className="neon-r">E</span>
          <span className="neon-g">G</span>
          <span className="neon-b">R</span>
          <span className="neon-r">I</span>
          <span className="neon-g">T</span>
          <span className="neon-b">Y</span>
        </span>
        <label className="strict-toggle" title="Enables fullscreen enforcement and a devtools heuristic">
          <input type="checkbox" checked={strict} onChange={(e) => onToggleStrict(e.target.checked)} />
          Strict mode
        </label>
      </div>

      {cameraOn && <div className="camera-slot">{children}</div>}

      <div className="status-chip-grid">
        <StatusChip
          label="Vision"
          kind={visionKind}
          text={visionText}
          onClick={() => onToggleCamera(!cameraOn)}
          actionLabel={cameraOn ? "Turn off" : "Turn on"}
        />
        <StatusChip
          label="Tab focus"
          kind={tabFocused ? "ok" : "notice"}
          text={tabFocused ? "In focus" : "Not focused"}
        />
        {strict && (
          <StatusChip
            label="Fullscreen"
            kind={isFullscreen ? "ok" : "notice"}
            text={isFullscreen ? "Active" : "Inactive"}
            onClick={!isFullscreen ? onRequestFullscreen : undefined}
            actionLabel={!isFullscreen ? "Enter" : undefined}
          />
        )}
      </div>

      <div className="integrity-counts">
        <span className="count-pill count-high">{counts.high} high</span>
        <span className="count-pill count-medium">{counts.medium} med</span>
        <span className="count-pill count-low">{counts.low} low</span>
        <span className="count-total">{events.length} logged · weight {totalWeight}</span>
      </div>

      <div className="integrity-feed">
        {recent.length === 0 && (
          <div className="integrity-feed-empty">No observations yet. This is normal.</div>
        )}
        {recent.map((e, i) => {
          const meta = eventMeta(e.type);
          return (
            <div className={`integrity-feed-row severity-${meta.severity}`} key={`${e.timestamp}-${i}`}>
              <span className="integrity-feed-icon">{meta.icon}</span>
              <div className="integrity-feed-body">
                <span className="integrity-feed-label">{meta.label}</span>
                <span className="integrity-feed-detail">{e.detail}</span>
              </div>
              <span className="integrity-feed-time">
                {new Date(e.timestamp).toLocaleTimeString([], { hour: "2-digit", minute: "2-digit", second: "2-digit" })}
              </span>
            </div>
          );
        })}
      </div>

      <p className="integrity-disclaimer">
        Observations only — never a verdict. Reviewed by a human, not auto-scored.
      </p>
    </div>
  );
}

function StatusChip({ label, kind, text, onClick, actionLabel }) {
  return (
    <div className={`status-chip status-chip-${kind}`}>
      <span className="status-chip-dot" />
      <div className="status-chip-text">
        <span className="status-chip-label">{label}</span>
        <span className="status-chip-value">{text}</span>
      </div>
      {onClick && actionLabel && (
        <button type="button" className="status-chip-action" onClick={onClick}>
          {actionLabel}
        </button>
      )}
    </div>
  );
}
