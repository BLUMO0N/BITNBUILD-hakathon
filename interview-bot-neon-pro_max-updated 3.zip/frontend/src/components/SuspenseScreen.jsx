// components/SuspenseScreen.jsx
//
// Shown to the CANDIDATE immediately after their last answer. On purpose,
// this never shows a score, a verdict, or the integrity log - that's the
// whole point of gating the report behind HR's passkey (see
// HRAccessGate.jsx). The candidate gets confirmation their session was
// recorded and a clear, honest explanation of what happens next.

export default function SuspenseScreen({ onOpenHrGate, onRestart }) {
  return (
    <div className="card suspense-card">
      <div className="suspense-orb">
        <span className="suspense-orb-ring" />
        <span className="suspense-orb-core">✓</span>
      </div>

      <div className="eyebrow">INTERVIEW SUBMITTED</div>
      <h1 className="hero-title">
        Thanks — that's a{" "}
        <span className="neon-text">
          <span className="neon-r">w</span>
          <span className="neon-g">r</span>
          <span className="neon-b">a</span>
          <span className="neon-r">p</span>
        </span>
      </h1>
      <p className="subtitle">
        Your responses and attention log have been recorded and sent for review. No score
        or result is shown here — this interview is evaluated by the hiring team, not
        self-graded, so what happens next is entirely in their hands.
      </p>

      <ul className="suspense-checklist">
        <li>
          <span className="check-dot check-dot-ok" /> Responses recorded
        </li>
        <li>
          <span className="check-dot check-dot-ok" /> Integrity log compiled
        </li>
        <li>
          <span className="check-dot check-dot-pending" /> Awaiting HR review
        </li>
      </ul>

      <div className="suspense-actions">
        <button className="primary-btn" onClick={onOpenHrGate}>
          🔒 HR / Admin Access
        </button>
        <button className="ghost-btn" onClick={onRestart}>
          Start a new interview session
        </button>
      </div>

      <p className="start-footnote">
        If you're the candidate, you're done here — you can close this tab. If you're
        HR reviewing this session on this device, use the button above.
      </p>
    </div>
  );
}
