// api.js - thin wrapper around the backend REST API.

const API_URL = import.meta.env.VITE_API_URL || "http://localhost:5000";

async function handle(res) {
  const data = await res.json().catch(() => ({}));
  if (!res.ok) {
    throw new Error(data.error || `Request failed (${res.status})`);
  }
  return data;
}

export async function startInterview({ role, resumeText, resumeFile }) {
  const form = new FormData();
  form.append("role", role);
  if (resumeText) form.append("resumeText", resumeText);
  if (resumeFile) form.append("resumeFile", resumeFile);

  const res = await fetch(`${API_URL}/api/interview/start`, {
    method: "POST",
    body: form,
  });
  return handle(res);
}

export async function submitAnswer({ sessionId, answer }) {
  const res = await fetch(`${API_URL}/api/interview/answer`, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ sessionId, answer }),
  });
  return handle(res);
}

// Closes out the interview and triggers report generation SERVER-SIDE,
// but deliberately does NOT return the report to the candidate. See
// HRAccessGate.jsx / fetchHrReport() for how the report is actually
// retrieved, later, by HR.
export async function submitForReview({ sessionId }) {
  const res = await fetch(`${API_URL}/api/interview/finish`, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ sessionId }),
  });
  return handle(res);
}

// HR/admin-only: unlocks the report for a session with the shared
// passkey. The passkey is checked server-side (backend/src/services/
// hrAccess.js) - it is never compared in the browser.
export async function fetchHrReport({ sessionId, passkey }) {
  const res = await fetch(`${API_URL}/api/interview/report`, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ sessionId, passkey }),
  });
  return handle(res);
}

export async function logIntegrityEvent({ sessionId, type, detail }) {
  // Best-effort — never blocks or breaks the interview if this fails.
  try {
    await fetch(`${API_URL}/api/interview/integrity-event`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ sessionId, type, detail }),
    });
  } catch (err) {
    console.warn("Failed to log integrity event:", err.message);
  }
}
