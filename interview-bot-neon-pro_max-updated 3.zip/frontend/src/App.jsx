import { useState } from "react";
import StartScreen from "./components/StartScreen.jsx";
import InterviewScreen from "./components/InterviewScreen.jsx";
import SuspenseScreen from "./components/SuspenseScreen.jsx";
import ReportScreen from "./components/ReportScreen.jsx";
import HRAccessGate from "./components/HRAccessGate.jsx";
import ThemeToggle from "./components/ThemeToggle.jsx";
import FloatingOrbs from "./components/FloatingOrbs.jsx";
import { useTheme } from "./hooks/useTheme.js";
import { startInterview, submitForReview, fetchHrReport } from "./api.js";

// screen: 'start' | 'interview' | 'complete' | 'report'
export default function App() {
  const { theme, toggleTheme } = useTheme();
  const [screen, setScreen] = useState("start");
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState(null);

  const [sessionId, setSessionId] = useState(null);
  const [question, setQuestion] = useState(null);
  const [questionNumber, setQuestionNumber] = useState(1);
  const [maxQuestions, setMaxQuestions] = useState(5);

  const [report, setReport] = useState(null);
  const [integrityEvents, setIntegrityEvents] = useState([]);

  const [hrGateOpen, setHrGateOpen] = useState(false);
  const [hrLoading, setHrLoading] = useState(false);
  const [hrError, setHrError] = useState(null);

  async function handleStart({ role, resumeText, resumeFile }) {
    setLoading(true);
    setError(null);
    try {
      const result = await startInterview({ role, resumeText, resumeFile });
      setSessionId(result.sessionId);
      setQuestion(result.question);
      setQuestionNumber(result.questionNumber);
      setMaxQuestions(result.maxQuestions);
      setScreen("interview");
    } catch (err) {
      setError(err.message);
    } finally {
      setLoading(false);
    }
  }

  async function handleAnswered(result) {
    if (result.done) {
      try {
        // Closes out the session and triggers report generation
        // server-side, but the response deliberately carries no score or
        // report content - see api.js / SuspenseScreen.jsx.
        await submitForReview({ sessionId });
        setScreen("complete");
      } catch (err) {
        setError(err.message);
      }
    } else {
      setQuestion(result.question);
      setQuestionNumber(result.questionNumber);
    }
  }

  async function handleHrSubmit(passkey) {
    setHrLoading(true);
    setHrError(null);
    try {
      const result = await fetchHrReport({ sessionId, passkey });
      setReport(result.report);
      setIntegrityEvents(result.integrityEvents || []);
      setHrGateOpen(false);
      setScreen("report");
    } catch (err) {
      setHrError(err.message);
    } finally {
      setHrLoading(false);
    }
  }

  function handleRestart() {
    setScreen("start");
    setSessionId(null);
    setQuestion(null);
    setQuestionNumber(1);
    setReport(null);
    setIntegrityEvents([]);
    setError(null);
    setHrError(null);
    setHrGateOpen(false);
  }

  const canOpenHrGate = screen === "complete" || screen === "report";

  return (
    <div className="app-shell">
      <div className="bg-grid" aria-hidden="true" />
      <div className="bg-glow bg-glow-1" aria-hidden="true" />
      <div className="bg-glow bg-glow-2" aria-hidden="true" />
      <div className="bg-glow bg-glow-3" aria-hidden="true" />
      <div className="bg-glow bg-glow-4" aria-hidden="true" />
      <FloatingOrbs count={18} />

      <header className="app-header">
        <div className="brand">
          <span className="brand-mark" aria-hidden="true">
            ◈
          </span>
          <span className="brand-text neon-text">
            <span className="neon-r">NEURAL</span>
            <span className="brand-text-gap" />
            <span className="neon-g">INTERVIEW</span>
            <span className="brand-text-gap" />
            <span className="neon-b">GUARD</span>
          </span>
        </div>
        <div className="header-status">
          {screen === "interview" && (
            <span className="live-badge">
              <span className="live-dot" /> LIVE SESSION
            </span>
          )}
          <ThemeToggle theme={theme} onToggle={toggleTheme} />
        </div>
      </header>

      <main className="app-main">
        {screen === "start" && (
          <StartScreen onStart={handleStart} loading={loading} error={error} />
        )}
        {screen === "interview" && (
          <InterviewScreen
            sessionId={sessionId}
            question={question}
            questionNumber={questionNumber}
            maxQuestions={maxQuestions}
            onAnswered={handleAnswered}
          />
        )}
        {screen === "complete" && (
          <SuspenseScreen onOpenHrGate={() => setHrGateOpen(true)} onRestart={handleRestart} />
        )}
        {screen === "report" && (
          <ReportScreen report={report} integrityEvents={integrityEvents} onRestart={handleRestart} />
        )}
      </main>

      <footer className="app-footer">
        Client-side monitoring only · results are reviewed by HR, not shown to candidates
        {canOpenHrGate && (
          <>
            {" "}
            ·{" "}
            <button className="footer-link-btn" onClick={() => setHrGateOpen(true)}>
              HR / Admin Access
            </button>
          </>
        )}
      </footer>

      {hrGateOpen && (
        <HRAccessGate
          onSubmit={handleHrSubmit}
          onClose={() => {
            setHrGateOpen(false);
            setHrError(null);
          }}
          loading={hrLoading}
          error={hrError}
        />
      )}
    </div>
  );
}
