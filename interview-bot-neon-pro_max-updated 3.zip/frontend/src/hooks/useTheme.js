// hooks/useTheme.js — persisted light/dark theme toggle.
//
// Applies a `data-theme` attribute to <html>, which styles.css keys off
// of via CSS variables. Falls back to the OS-level color-scheme
// preference on first load, then remembers whatever the user picks.

import { useCallback, useEffect, useState } from "react";

const STORAGE_KEY = "interview-bot-theme";

function getInitialTheme() {
  if (typeof window === "undefined") return "dark";
  try {
    const stored = window.localStorage.getItem(STORAGE_KEY);
    if (stored === "light" || stored === "dark") return stored;
  } catch {
    // localStorage can throw in some private-browsing contexts - fine,
    // just fall through to the media-query default below.
  }
  const prefersLight =
    typeof window.matchMedia === "function" &&
    window.matchMedia("(prefers-color-scheme: light)").matches;
  return prefersLight ? "light" : "dark";
}

export function useTheme() {
  const [theme, setTheme] = useState(getInitialTheme);

  useEffect(() => {
    document.documentElement.setAttribute("data-theme", theme);
    try {
      window.localStorage.setItem(STORAGE_KEY, theme);
    } catch {
      // best-effort persistence only
    }
  }, [theme]);

  const toggleTheme = useCallback(() => {
    setTheme((t) => (t === "dark" ? "light" : "dark"));
  }, []);

  return { theme, setTheme, toggleTheme };
}
