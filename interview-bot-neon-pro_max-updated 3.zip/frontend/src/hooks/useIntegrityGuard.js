// hooks/useIntegrityGuard.js
//
// Browser-level integrity signals that complement CameraMonitor's
// vision-based checks. Same philosophy throughout this app: every signal
// is a neutral, timestamped OBSERVATION - never a verdict, never
// something that blocks or penalizes the candidate by itself. Consumers
// (InterviewScreen / IntegrityConsole / the final report) decide how to
// surface these.
//
// Signals emitted via onEvent:
//   tab_hidden          - the tab/window lost visibility or focus
//   fullscreen_exited    - candidate left fullscreen (only fires in
//                          strict mode, since fullscreen is opt-in)
//   paste_detected        - text was pasted into a bound element
//                          (typically the answer box)
//   devtools_suspected   - a heuristic (outer vs. inner window size
//                          mismatch) that *may* indicate devtools are
//                          open. Deliberately framed as "suspected", not
//                          "detected" - this check has real false
//                          positives (e.g. genuinely small windows,
//                          browser toolbars) and only runs in strict mode.

import { useCallback, useEffect, useRef, useState } from "react";

const DEVTOOLS_CHECK_INTERVAL_MS = 2000;
const DEVTOOLS_THRESHOLD_PX = 180;
const EVENT_COOLDOWN_MS = 8000;

export function useIntegrityGuard({ enabled, strict = false, onEvent }) {
  const [tabFocused, setTabFocused] = useState(true);
  const [isFullscreen, setIsFullscreen] = useState(!!document.fullscreenElement);
  const lastFiredAtRef = useRef({});
  const onEventRef = useRef(onEvent);
  onEventRef.current = onEvent;

  const fire = useCallback((type, detail) => {
    const now = Date.now();
    const last = lastFiredAtRef.current[type] || 0;
    if (now - last < EVENT_COOLDOWN_MS) return;
    lastFiredAtRef.current[type] = now;
    onEventRef.current?.({ type, detail });
  }, []);

  // Tab visibility / window focus.
  useEffect(() => {
    if (!enabled) return;

    function handleVisibility() {
      const hidden = document.hidden;
      setTabFocused(!hidden);
      if (hidden) fire("tab_hidden", "Candidate switched tabs or minimized the window");
    }
    function handleBlur() {
      setTabFocused(false);
      fire("tab_hidden", "Interview window lost focus");
    }
    function handleFocus() {
      setTabFocused(true);
    }

    document.addEventListener("visibilitychange", handleVisibility);
    window.addEventListener("blur", handleBlur);
    window.addEventListener("focus", handleFocus);
    return () => {
      document.removeEventListener("visibilitychange", handleVisibility);
      window.removeEventListener("blur", handleBlur);
      window.removeEventListener("focus", handleFocus);
    };
  }, [enabled, fire]);

  // Fullscreen state tracking (fires an event only in strict mode, since
  // fullscreen itself is opt-in there).
  useEffect(() => {
    function handleFsChange() {
      const fs = !!document.fullscreenElement;
      setIsFullscreen(fs);
      if (!fs && enabled && strict) {
        fire("fullscreen_exited", "Candidate exited fullscreen mode");
      }
    }
    document.addEventListener("fullscreenchange", handleFsChange);
    return () => document.removeEventListener("fullscreenchange", handleFsChange);
  }, [enabled, strict, fire]);

  // DevTools heuristic - low-confidence, opt-in via strict mode only.
  useEffect(() => {
    if (!enabled || !strict) return;
    const id = setInterval(() => {
      const widthDelta = window.outerWidth - window.innerWidth;
      const heightDelta = window.outerHeight - window.innerHeight;
      if (widthDelta > DEVTOOLS_THRESHOLD_PX || heightDelta > DEVTOOLS_THRESHOLD_PX) {
        fire(
          "devtools_suspected",
          "Browser viewport size suggests developer tools may be open"
        );
      }
    }, DEVTOOLS_CHECK_INTERVAL_MS);
    return () => clearInterval(id);
  }, [enabled, strict, fire]);

  const requestFullscreen = useCallback(() => {
    const el = document.documentElement;
    if (el.requestFullscreen) {
      el.requestFullscreen().catch(() => {
        // Not all browsers/contexts allow this (e.g. no user gesture) -
        // never block the interview on it.
      });
    }
  }, []);

  const exitFullscreen = useCallback(() => {
    if (document.fullscreenElement && document.exitFullscreen) {
      document.exitFullscreen().catch(() => {});
    }
  }, []);

  // Attach paste detection to an arbitrary element (typically the answer
  // textarea). Returns a cleanup function; call it from a ref callback or
  // a useEffect keyed on the element.
  const bindPasteDetection = useCallback(
    (element) => {
      if (!element) return () => {};
      function handlePaste(e) {
        if (!enabled) return;
        const text = e.clipboardData?.getData("text") || "";
        const wordCount = text.trim().split(/\s+/).filter(Boolean).length;
        fire(
          "paste_detected",
          wordCount > 0
            ? `Pasted ~${wordCount} word${wordCount === 1 ? "" : "s"} into the answer box`
            : "Pasted content into the answer box"
        );
      }
      element.addEventListener("paste", handlePaste);
      return () => element.removeEventListener("paste", handlePaste);
    },
    [enabled, fire]
  );

  return {
    tabFocused,
    isFullscreen,
    requestFullscreen,
    exitFullscreen,
    bindPasteDetection,
  };
}
