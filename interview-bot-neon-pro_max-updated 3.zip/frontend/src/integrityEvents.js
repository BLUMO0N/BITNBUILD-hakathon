// integrityEvents.js — shared display metadata for integrity observations.
//
// Every event type here is a NEUTRAL, timestamped OBSERVATION, not an
// accusation. "Severity" only controls how visually prominent the chip/
// log entry is (so a candidate glancing away briefly doesn't look the
// same as a second face appearing) — it is never surfaced as a verdict,
// score, or pass/fail signal. See CameraMonitor.jsx and
// useIntegrityGuard.js for where each type is actually emitted.

export const EVENT_META = {
  face_not_detected: {
    label: "Face not visible",
    severity: "high",
    icon: "◐",
  },
  multiple_faces: {
    label: "Multiple faces in frame",
    severity: "high",
    icon: "◎",
  },
  attention_observation: {
    label: "Attention shift",
    severity: "medium",
    icon: "◔",
  },
  camera_unavailable: {
    label: "Camera unavailable",
    severity: "low",
    icon: "○",
  },
  tab_hidden: {
    label: "Tab / window focus lost",
    severity: "medium",
    icon: "▣",
  },
  fullscreen_exited: {
    label: "Exited fullscreen",
    severity: "medium",
    icon: "▢",
  },
  paste_detected: {
    label: "Pasted text into answer",
    severity: "medium",
    icon: "▤",
  },
  devtools_suspected: {
    label: "DevTools suspected",
    severity: "low",
    icon: "▥",
  },
  copy_blocked: {
    label: "Copy attempt blocked",
    severity: "medium",
    icon: "⧉",
  },
  devtools_shortcut_blocked: {
    label: "DevTools shortcut blocked",
    severity: "medium",
    icon: "⌘",
  },
};

export function eventMeta(type) {
  return (
    EVENT_META[type] || {
      label: String(type || "observation").replace(/_/g, " "),
      severity: "low",
      icon: "•",
    }
  );
}

export const SEVERITY_WEIGHT = { low: 1, medium: 2, high: 3 };
