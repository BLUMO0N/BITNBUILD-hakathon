// routes/interview.js
// REST API for the interview flow. Kept as three endpoints matching the
// three milestones, plus one small endpoint for integrity/attention events.

import express from "express";
import multer from "multer";
import { v4 as uuidv4 } from "uuid";
import { askOllamaJSON } from "../services/ollama.js";
import {
  buildStartPrompt,
  buildAnswerPrompt,
  buildReportPrompt,
  isTechnicalRole,
  pickDsaQuestion,
} from "../services/prompts.js";
import {
  createSession,
  getSession,
  updateSession,
  addIntegrityEvent,
} from "../services/sessionStore.js";
import { extractResumeText } from "../services/resumeParser.js";
import {
  persistSessionStart,
  persistQuestionAnswer,
  persistReport,
  persistIntegrityEvent,
  markSessionCompleted,
} from "../services/supabase.js";
import { checkRateLimit, recordAttempt, verifyPasskey } from "../services/hrAccess.js";

const router = express.Router();
const upload = multer({ storage: multer.memoryStorage() });

const MAX_QUESTIONS = parseInt(process.env.MAX_QUESTIONS || "5", 10);

/**
 * MILESTONE 1
 * POST /api/interview/start
 * multipart/form-data:
 *   - resumeFile (optional file: pdf/docx/txt)
 *   - resumeText (optional string, used if no file uploaded / as extra context)
 *   - role (required string)
 *
 * Response: { sessionId, candidateProfile, question, difficulty, questionNumber, maxQuestions }
 */
router.post("/start", upload.single("resumeFile"), async (req, res) => {
  try {
    const role = (req.body.role || "").trim();
    if (!role) {
      return res.status(400).json({ error: "role is required" });
    }

    let resumeText = (req.body.resumeText || "").trim();
    if (req.file) {
      const fileText = await extractResumeText(req.file);
      resumeText = [resumeText, fileText].filter(Boolean).join("\n\n");
    }

    if (!resumeText) {
      return res
        .status(400)
        .json({ error: "resumeText or resumeFile is required" });
    }

    const prompt = buildStartPrompt(resumeText, role);
    const result = await askOllamaJSON(prompt);

    if (!result.firstQuestion || !result.candidateProfile) {
      throw new Error("Model response missing required fields");
    }

    const sessionId = uuidv4();
    const session = createSession({
      sessionId,
      role,
      resumeText,
      candidateProfile: result.candidateProfile,
    });

    session.currentQuestion = result.firstQuestion;
    session.currentDifficulty = result.difficulty || "medium";
    session.questionNumber = 1;
    updateSession(sessionId, session);

    persistSessionStart(session); // fire-and-forget, safe no-op if unconfigured

    return res.json({
      sessionId,
      candidateProfile: session.candidateProfile,
      question: session.currentQuestion,
      difficulty: session.currentDifficulty,
      questionNumber: session.questionNumber,
      maxQuestions: MAX_QUESTIONS,
    });
  } catch (err) {
    console.error("[/start] error:", err.message);
    return res.status(500).json({ error: err.message });
  }
});

/**
 * MILESTONE 2
 * POST /api/interview/answer
 * JSON body: { sessionId, answer }
 *
 * Response: either
 *   { done: false, question, difficulty, questionNumber, maxQuestions, lastEvaluation }
 * or
 *   { done: true, lastEvaluation }  (frontend should then call /finish)
 */
router.post("/answer", express.json(), async (req, res) => {
  try {
    const { sessionId, answer } = req.body;
    if (!sessionId || !answer) {
      return res.status(400).json({ error: "sessionId and answer are required" });
    }

    const session = getSession(sessionId);
    if (!session) {
      return res.status(404).json({ error: "session not found" });
    }
    if (session.status === "completed") {
      return res.status(400).json({ error: "interview already completed" });
    }

    const prompt = buildAnswerPrompt({
      role: session.role,
      candidateProfile: session.candidateProfile,
      history: session.history,
      currentQuestion: session.currentQuestion,
      candidateAnswer: answer,
      questionNumber: session.questionNumber,
      maxQuestions: MAX_QUESTIONS,
    });

    const result = await askOllamaJSON(prompt);

    const entry = {
      question: session.currentQuestion,
      answer,
      evaluation: result.evaluation,
    };
    session.history.push(entry);
    persistQuestionAnswer(sessionId, session.questionNumber, entry);

    const isComplete =
      Boolean(result.isInterviewComplete) || session.questionNumber >= MAX_QUESTIONS;

    if (isComplete) {
      session.status = "ready_for_report";
      session.currentQuestion = null;
      updateSession(sessionId, session);
      return res.json({ done: true, lastEvaluation: result.evaluation });
    }

    // GUARANTEED DSA QUESTION: for technical/software roles, make sure at
    // least one Data Structures & Algorithms question appears in the
    // interview, deterministically - rather than just hoping the model's
    // free-form choice includes one (per prompts.js it's encouraged to,
    // but this makes it certain). Injected once, roughly two-thirds of
    // the way through, well clear of the very first and very last
    // question. Only kicks in when there's room for it.
    const nextQuestionNumber = session.questionNumber + 1;
    const dsaSlot = Math.max(2, Math.min(3, MAX_QUESTIONS - 1));
    const shouldInjectDsa =
      !session.dsaInjected &&
      isTechnicalRole(session.role) &&
      MAX_QUESTIONS >= 3 &&
      nextQuestionNumber === dsaSlot;

    if (shouldInjectDsa) {
      const askedAlready = session.history.map((h) => h.question);
      session.currentQuestion = pickDsaQuestion(askedAlready);
      session.currentDifficulty = result.nextDifficulty || session.currentDifficulty;
      session.dsaInjected = true;
    } else {
      session.currentQuestion = result.nextQuestion;
      session.currentDifficulty = result.nextDifficulty || session.currentDifficulty;
    }
    session.questionNumber += 1;
    updateSession(sessionId, session);

    return res.json({
      done: false,
      question: session.currentQuestion,
      difficulty: session.currentDifficulty,
      questionNumber: session.questionNumber,
      maxQuestions: MAX_QUESTIONS,
      lastEvaluation: result.evaluation,
    });
  } catch (err) {
    console.error("[/answer] error:", err.message);
    return res.status(500).json({ error: err.message });
  }
});

/**
 * MILESTONE 3 (revised)
 * POST /api/interview/finish
 * JSON body: { sessionId }
 *
 * Generates and stores the report server-side, exactly as before - but
 * the candidate-facing response is now deliberately just a confirmation.
 * This is the interview integrity philosophy applied to the SCORE itself,
 * not just the observations: this is a real interview conducted by an
 * AI standing in for HR, not a self-graded quiz, so the result isn't
 * revealed at the desk. It's only ever readable via GET-style
 * POST /api/interview/report, gated by the HR passkey below.
 *
 * Response: { ok: true, status: "submitted" }
 */
router.post("/finish", express.json(), async (req, res) => {
  try {
    const { sessionId } = req.body;
    if (!sessionId) {
      return res.status(400).json({ error: "sessionId is required" });
    }

    const session = getSession(sessionId);
    if (!session) {
      return res.status(404).json({ error: "session not found" });
    }
    if (session.history.length === 0) {
      return res
        .status(400)
        .json({ error: "cannot generate a report with no answered questions" });
    }

    const prompt = buildReportPrompt({
      role: session.role,
      candidateProfile: session.candidateProfile,
      history: session.history,
    });

    const report = await askOllamaJSON(prompt);

    session.status = "completed";
    session.report = report;
    updateSession(sessionId, session);

    persistReport(sessionId, report);
    markSessionCompleted(sessionId);

    return res.json({ ok: true, status: "submitted" });
  } catch (err) {
    console.error("[/finish] error:", err.message);
    return res.status(500).json({ error: err.message });
  }
});

/**
 * MILESTONE 7 — HR-gated report access
 * POST /api/interview/report
 * JSON body: { sessionId, passkey }
 *
 * Returns the report + integrity log ONLY if the passkey matches
 * HR_ACCESS_KEY (see services/hrAccess.js). Rate-limited per IP to slow
 * down guessing. The candidate's own /finish call never sees this data.
 *
 * Response: { report, integrityEvents, role, candidateProfile }
 */
router.post("/report", express.json(), async (req, res) => {
  try {
    const ip = req.ip || req.socket?.remoteAddress || "unknown";
    const { allowed, retryAfterMs } = checkRateLimit(ip);
    if (!allowed) {
      return res.status(429).json({
        error: `Too many attempts. Try again in ${Math.ceil(retryAfterMs / 1000)}s.`,
      });
    }

    const { sessionId, passkey } = req.body;
    if (!sessionId || !passkey) {
      return res.status(400).json({ error: "sessionId and passkey are required" });
    }

    if (!verifyPasskey(passkey)) {
      recordAttempt(ip, false);
      return res.status(403).json({ error: "Incorrect passkey" });
    }
    recordAttempt(ip, true);

    const session = getSession(sessionId);
    if (!session) {
      return res.status(404).json({ error: "session not found" });
    }
    if (session.status !== "completed" || !session.report) {
      return res.status(409).json({ error: "Report not ready yet — the candidate hasn't finished." });
    }

    return res.json({
      report: session.report,
      integrityEvents: session.integrityEvents,
      role: session.role,
      candidateProfile: session.candidateProfile,
    });
  } catch (err) {
    console.error("[/report] error:", err.message);
    return res.status(500).json({ error: err.message });
  }
});

/**
 * MILESTONE 5
 * POST /api/interview/integrity-event
 * JSON body: { sessionId, type, detail }
 * type examples: 'face_not_detected', 'multiple_faces', 'attention_observation', 'camera_unavailable'
 * This only ever RECORDS observations. It never labels or scores them.
 */
router.post("/integrity-event", express.json(), async (req, res) => {
  try {
    const { sessionId, type, detail } = req.body;
    if (!sessionId || !type) {
      return res.status(400).json({ error: "sessionId and type are required" });
    }
    const session = addIntegrityEvent(sessionId, { type, detail });
    if (!session) {
      return res.status(404).json({ error: "session not found" });
    }
    persistIntegrityEvent(sessionId, {
      type,
      detail,
      timestamp: new Date().toISOString(),
    });
    return res.json({ ok: true });
  } catch (err) {
    console.error("[/integrity-event] error:", err.message);
    return res.status(500).json({ error: err.message });
  }
});

export default router;
