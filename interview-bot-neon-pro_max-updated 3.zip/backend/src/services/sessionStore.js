// services/sessionStore.js
// Simple in-memory session store. This is intentionally NOT a database:
// for a 6-hour hackathon, an in-memory Map is enough to run the interview
// loop reliably. Supabase (services/supabase.js) mirrors this data for
// persistence, but the live interview logic never depends on Supabase
// being configured.

const sessions = new Map();

export function createSession({ sessionId, role, resumeText, candidateProfile }) {
  const session = {
    sessionId,
    role,
    resumeText,
    candidateProfile,
    history: [], // [{ question, answer, evaluation }]
    integrityEvents: [], // [{ type, detail, timestamp }]
    currentQuestion: null,
    questionNumber: 0,
    status: "in_progress", // in_progress | completed
    dsaInjected: false, // has a guaranteed DSA question been asked this session yet?
    createdAt: new Date().toISOString(),
  };
  sessions.set(sessionId, session);
  return session;
}

export function getSession(sessionId) {
  return sessions.get(sessionId) || null;
}

export function updateSession(sessionId, updates) {
  const session = sessions.get(sessionId);
  if (!session) return null;
  Object.assign(session, updates);
  sessions.set(sessionId, session);
  return session;
}

export function addIntegrityEvent(sessionId, event) {
  const session = sessions.get(sessionId);
  if (!session) return null;
  session.integrityEvents.push({ ...event, timestamp: new Date().toISOString() });
  return session;
}
