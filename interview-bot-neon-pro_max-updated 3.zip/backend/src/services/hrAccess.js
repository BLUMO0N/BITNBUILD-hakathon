// services/hrAccess.js
//
// Gates the interview REPORT behind a shared HR/admin passkey, checked
// server-side (never shipped to the browser bundle). This is intentionally
// simple - one shared passkey, in-memory rate limiting - appropriate for a
// hackathon prototype run on a single machine. It is NOT a real auth
// system: there's no per-HR-user identity, and the in-memory attempt
// tracker resets on server restart. For a production deployment this
// should become real authentication (e.g. Supabase auth + a `role`
// column) rather than one shared secret.

const MAX_ATTEMPTS = 5;
const LOCKOUT_MS = 60 * 1000; // 1 minute

const attempts = new Map(); // ip -> { count, lockedUntil }

function getDefaultKey() {
  // A fallback so the demo works out of the box, but this is loudly
  // logged at startup (see server.js) so nobody ships this default.
  return "1234";
}

export function getHrAccessKey() {
  // HARD-LOCKED to "1234": deliberately ignoring process.env.HR_ACCESS_KEY
  // here so this always works the same way regardless of whatever a local
  // .env file on any given machine happens to contain (a stale value from
  // before, a typo, etc.). To make this configurable again later, change
  // this back to: return process.env.HR_ACCESS_KEY?.trim() || getDefaultKey();
  return getDefaultKey();
}

export function isUsingDefaultHrKey() {
  return true;
}

/**
 * Returns { allowed: boolean, retryAfterMs?: number } - call BEFORE
 * checking the passkey so a locked-out caller never even reaches the
 * comparison.
 */
export function checkRateLimit(ip) {
  const entry = attempts.get(ip);
  if (!entry) return { allowed: true };
  if (entry.lockedUntil && entry.lockedUntil > Date.now()) {
    return { allowed: false, retryAfterMs: entry.lockedUntil - Date.now() };
  }
  return { allowed: true };
}

export function recordAttempt(ip, success) {
  if (success) {
    attempts.delete(ip);
    return;
  }
  const entry = attempts.get(ip) || { count: 0, lockedUntil: 0 };
  entry.count += 1;
  if (entry.count >= MAX_ATTEMPTS) {
    entry.lockedUntil = Date.now() + LOCKOUT_MS;
    entry.count = 0;
  }
  attempts.set(ip, entry);
}

export function verifyPasskey(passkey) {
  return typeof passkey === "string" && passkey === getHrAccessKey();
}
