// services/ollama.js
// Thin wrapper around a local Ollama instance. All AI reasoning (resume
// understanding, question generation, answer evaluation, adaptive next
// question, final report) is delegated to the model through this module.

const OLLAMA_URL = process.env.OLLAMA_URL || "http://localhost:11434";
const OLLAMA_MODEL = process.env.OLLAMA_MODEL || "qwen3:8b";

// --- PERFORMANCE FIX (was: multi-second "lag" after submitting an answer) -
// qwen3 is a hybrid "thinking" model: by default it silently generates a
// long internal <think>...</think> reasoning trace before it ever starts
// the JSON we actually asked for, and that trace is what was burning most
// of the wall-clock time on every /start, /answer and /finish call - not
// the JSON generation itself, which is short. Three changes fix this
// without changing any behavior the app relies on:
//   1. `think: false` - tells Ollama (recent versions support this for
//      hybrid-reasoning models like qwen3) to skip the reasoning phase
//      entirely. This is the single biggest win. safeParseJSON's
//      <think> stripping below is kept as a harmless no-op fallback for
//      older Ollama builds that ignore this flag.
//   2. `num_predict` - caps generation length. Our JSON responses are a
//      few hundred tokens at most; without a cap a model that drifts
//      keeps generating (and the request keeps waiting) far longer than
//      it needs to.
//   3. `keep_alive` - keeps the model weights resident in memory between
//      requests instead of Ollama unloading/reloading them, which avoids
//      an extra multi-second reload spike on the next call after any
//      idle gap.
// A 90s client-side timeout (AbortController) also guarantees a request
// fails fast with a clear error instead of hanging indefinitely if Ollama
// itself stalls.
const REQUEST_TIMEOUT_MS = 90_000;

/**
 * Calls Ollama's /api/generate endpoint and forces JSON-mode output so the
 * rest of the app can rely on structured data instead of parsing prose.
 *
 * @param {string} prompt - full prompt (system + task instructions inlined)
 * @returns {Promise<object>} parsed JSON object from the model
 */
export async function askOllamaJSON(prompt) {
  const controller = new AbortController();
  const timeout = setTimeout(() => controller.abort(), REQUEST_TIMEOUT_MS);

  let res;
  try {
    res = await fetch(`${OLLAMA_URL}/api/generate`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      signal: controller.signal,
      body: JSON.stringify({
        model: OLLAMA_MODEL,
        prompt,
        format: "json", // Ollama JSON mode - guarantees syntactically valid JSON
        stream: false,
        think: false, // skip qwen3's reasoning trace - see notes above
        keep_alive: "30m", // keep weights loaded between requests
        options: {
          temperature: 0.4,
          num_predict: 700, // plenty for our JSON shapes, stops runaway generation
        },
      }),
    });
  } catch (err) {
    if (err.name === "AbortError") {
      throw new Error(
        `Ollama request timed out after ${REQUEST_TIMEOUT_MS / 1000}s. Is Ollama running and responsive?`
      );
    }
    throw err;
  } finally {
    clearTimeout(timeout);
  }

  if (!res.ok) {
    const text = await res.text().catch(() => "");
    throw new Error(
      `Ollama request failed (${res.status}): ${text || res.statusText}`
    );
  }

  const data = await res.json();
  const raw = data.response ?? "";

  return safeParseJSON(raw);
}

/**
 * qwen3 sometimes wraps its <think> reasoning or code fences around the
 * JSON even in JSON mode. This strips common wrappers before parsing, and
 * falls back to extracting the first {...} block if needed.
 */
function safeParseJSON(raw) {
  let text = String(raw).trim();

  // Strip <think>...</think> blocks some Qwen models emit
  text = text.replace(/<think>[\s\S]*?<\/think>/gi, "").trim();

  // Strip markdown code fences if present
  text = text.replace(/^```json\s*/i, "").replace(/^```\s*/i, "");
  text = text.replace(/```\s*$/i, "").trim();

  try {
    return JSON.parse(text);
  } catch (err) {
    // Fallback: grab the first {...} block in the text
    const match = text.match(/\{[\s\S]*\}/);
    if (match) {
      try {
        return JSON.parse(match[0]);
      } catch (err2) {
        throw new Error(
          `Model did not return valid JSON. Raw output: ${text.slice(0, 500)}`
        );
      }
    }
    throw new Error(
      `Model did not return valid JSON. Raw output: ${text.slice(0, 500)}`
    );
  }
}

export async function checkOllamaHealth() {
  try {
    const res = await fetch(`${OLLAMA_URL}/api/tags`);
    if (!res.ok) return { ok: false, error: `status ${res.status}` };
    const data = await res.json();
    const models = (data.models || []).map((m) => m.name);
    return { ok: true, models, targetModel: OLLAMA_MODEL };
  } catch (err) {
    return { ok: false, error: err.message };
  }
}
