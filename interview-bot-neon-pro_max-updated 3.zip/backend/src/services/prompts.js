// services/prompts.js
// All prompt templates in one place so Developer 3 (AI/prompt logic) can
// tune them without touching route or service code.

// A curated bank of spoken-friendly Data Structures & Algorithms questions
// (conceptual/verbal - no live code editor in this app). Used two ways:
//   1. Referenced in the prompts below so the model knows DSA questions are
//      welcome for technical roles.
//   2. Deterministically injected once per session by routes/interview.js
//      for technical roles, so a DSA question is GUARANTEED to appear even
//      if the model doesn't happen to generate one on its own.
export const DSA_QUESTION_BANK = [
  "How would you reverse a singly linked list? Walk through your approach and its time and space complexity.",
  "How would you detect a cycle in a linked list? What's the name of the classic algorithm for this, and what's its time complexity?",
  "Given an array of integers and a target sum, how would you find two numbers that add up to it? What's the time complexity of your approach, and can you do better than the brute-force one?",
  "What's the difference between BFS and DFS on a graph or tree, and when would you choose one over the other?",
  "How does binary search work, and what precondition must the input satisfy for it to be correct?",
  "How does a hash map achieve average O(1) lookup, and what causes its performance to degrade toward O(n)?",
  "Can you walk me through how quicksort works, and describe its best-case and worst-case time complexity?",
  "How would you find the kth largest element in an unsorted array, and what approaches would you compare for efficiency?",
  "What is dynamic programming, and can you describe a classic problem it's used to solve?",
  "How would you check whether a binary tree is height-balanced?",
  "How would you find the first non-repeating character in a string, and what's the time complexity of your approach?",
  "What's the difference between a stack and a queue, and can you give a real use case for each?",
];

const DSA_ROLE_KEYWORDS =
  /software|developer|engineer|programmer|\bsde\b|full[\s-]?stack|front[\s-]?end|back[\s-]?end|dev[\s-]?ops|\bqa\b|\bsdet\b|computer science|coder|\bcs\b|machine learning|data scien|ml engineer|mobile developer|web developer/i;

/**
 * Whether a target role is technical enough that a DSA question is a
 * reasonable, expected part of the interview.
 */
export function isTechnicalRole(role) {
  return DSA_ROLE_KEYWORDS.test(String(role || ""));
}

/**
 * Picks a DSA question not already used in this session, so repeat
 * questions never happen even across a long interview.
 */
export function pickDsaQuestion(usedQuestions = []) {
  const unused = DSA_QUESTION_BANK.filter((q) => !usedQuestions.includes(q));
  const pool = unused.length > 0 ? unused : DSA_QUESTION_BANK;
  return pool[Math.floor(Math.random() * pool.length)];
}

export function buildStartPrompt(resumeText, role) {
  return `You are an expert technical interviewer preparing for a live interview.

CANDIDATE RESUME:
"""
${resumeText}
"""

TARGET ROLE: ${role}

TASK:
1. Read the resume and extract a concise candidate profile relevant to the target role.
2. Generate ONE strong opening interview question, personalized to this candidate and role.
   - Prefer a question that connects something specific in the resume to the target role.
   - Keep it open-ended, not yes/no.
   - If the target role is a software/technical role, later questions in this interview
     will include a Data Structures & Algorithms question, so keep the opening question
     resume/experience-focused rather than DSA.

Respond with ONLY a JSON object in exactly this shape, no extra text:
{
  "candidateProfile": {
    "name": "string or null if not found",
    "yearsOfExperience": "string, best estimate, e.g. '2 years' or 'fresher'",
    "keySkills": ["string", "..."],
    "notableProjects": ["short string", "..."],
    "summary": "2-3 sentence summary of the candidate relative to the target role"
  },
  "firstQuestion": "string",
  "difficulty": "easy | medium | hard"
}`;
}

export function buildAnswerPrompt({
  role,
  candidateProfile,
  history,
  currentQuestion,
  candidateAnswer,
  questionNumber,
  maxQuestions,
}) {
  const historyText = history
    .map(
      (h, i) =>
        `Q${i + 1}: ${h.question}\nA${i + 1}: ${h.answer}\nEvaluation: ${
          h.evaluation?.summary || "n/a"
        }`
    )
    .join("\n\n");

  const isLast = questionNumber >= maxQuestions;

  return `You are an expert technical interviewer conducting a live, adaptive interview.

TARGET ROLE: ${role}
CANDIDATE PROFILE: ${JSON.stringify(candidateProfile)}

INTERVIEW SO FAR:
${historyText || "(no previous questions)"}

CURRENT QUESTION: ${currentQuestion}
CANDIDATE'S ANSWER: """${candidateAnswer}"""

This is question ${questionNumber} of ${maxQuestions}.

TASK:
1. Evaluate the candidate's answer: identify strengths and weaknesses, and rate it.
2. Decide the direction and difficulty for the next question based on how they performed
   (go deeper if they did well, pivot or simplify if they struggled, avoid repeating topics).
   For technical/software roles, it's good to include a Data Structures & Algorithms
   question (arrays, linked lists, trees, graphs, sorting, complexity analysis) phrased
   conversationally for a spoken interview (no live code editor) if one hasn't come up yet.
3. ${
    isLast
      ? "This was the FINAL question. Do NOT generate another question — set nextQuestion to null and isInterviewComplete to true."
      : "Generate the next personalized interview question."
  }

Respond with ONLY a JSON object in exactly this shape, no extra text:
{
  "evaluation": {
    "score": "number from 1-10",
    "strengths": ["string", "..."],
    "weaknesses": ["string", "..."],
    "summary": "1-2 sentence evaluation of this specific answer"
  },
  "nextQuestion": ${isLast ? "null" : '"string"'},
  "nextDifficulty": ${isLast ? "null" : '"easy | medium | hard"'},
  "isInterviewComplete": ${isLast ? "true" : "false"}
}`;
}

export function buildReportPrompt({ role, candidateProfile, history }) {
  const historyText = history
    .map(
      (h, i) =>
        `Q${i + 1}: ${h.question}\nA${i + 1}: ${h.answer}\nScore: ${
          h.evaluation?.score ?? "n/a"
        }\nEvaluation notes: ${h.evaluation?.summary || "n/a"}`
    )
    .join("\n\n");

  return `You are an expert technical interviewer writing a final candidate report.

TARGET ROLE: ${role}
CANDIDATE PROFILE: ${JSON.stringify(candidateProfile)}

FULL INTERVIEW TRANSCRIPT AND PER-QUESTION EVALUATIONS:
${historyText}

TASK:
Write a final, balanced interview report. Be specific and evidence-based — reference
what the candidate actually said. Do NOT present this as a final hiring decision; it is
input for a human reviewer.

Respond with ONLY a JSON object in exactly this shape, no extra text:
{
  "overallScore": "number from 1-10",
  "strengths": ["string", "..."],
  "gaps": ["string", "..."],
  "technicalEvaluation": "2-4 sentences on role-related/technical competence",
  "communicationObservations": "1-3 sentences on clarity/communication, based only on what was observed",
  "summary": "3-5 sentence overall summary",
  "recommendation": "one of: 'Strong fit', 'Potential fit with gaps', 'Not a clear fit', 'Insufficient evidence'",
  "disclaimer": "This is AI-generated interview feedback intended to support, not replace, human hiring judgment."
}`;
}
