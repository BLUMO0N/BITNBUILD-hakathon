import "dotenv/config";
import express from "express";
import cors from "cors";
import interviewRoutes from "./routes/interview.js";
import { checkOllamaHealth } from "./services/ollama.js";
import { isSupabaseConfigured } from "./services/supabase.js";
import { isUsingDefaultHrKey, getHrAccessKey } from "./services/hrAccess.js";

const app = express();
const PORT = process.env.PORT || 5000;

app.use(cors());
app.use(express.json({ limit: "5mb" }));

app.get("/api/health", async (req, res) => {
  const ollama = await checkOllamaHealth();
  res.json({
    ok: true,
    ollama,
    supabaseConfigured: isSupabaseConfigured,
  });
});

app.use("/api/interview", interviewRoutes);

app.use((req, res) => {
  res.status(404).json({ error: "not found" });
});

app.listen(PORT, () => {
  console.log(`Interview Bot backend running on http://localhost:${PORT}`);
  console.log(`Health check: http://localhost:${PORT}/api/health`);
  if (isUsingDefaultHrKey()) {
    console.warn(
      `⚠️  HR/Admin report access passkey is: "${getHrAccessKey()}". This is hard-locked ` +
        `in backend/src/services/hrAccess.js (see the comment there to make it configurable).`
    );
  } else {
    console.log("HR report access: passkey loaded from HR_ACCESS_KEY.");
  }
});
