// utils/integrityEvents.js
//
// One tiny shared formatter so the live "Interview Integrity" timeline
// (InterviewScreen) and the final report (ReportScreen) render the same
// event shape identically instead of drifting apart. Always neutral,
// observation-only language - never "cheating" / "suspicious" / a score.

const DIRECTION_LABELS = {
  left: "Looking left",
  right: "Looking right",
  up: "Looking up",
  down: "Looking down",
  center: "Looking at screen",
};

const TYPE_LABELS = {
  attention_observation: "Attention observation",
  face_not_detected: "Face not detected",
  multiple_faces: "Multiple faces detected",
  camera_unavailable: "Camera unavailable",
};

/**
 * @param {{type: string, direction?: string, durationMs?: number, detail?: string}} event
 * @returns {string} a short, neutral, human-readable line for one event.
 */
export function formatIntegrityEvent(event) {
  const durationSuffix =
    typeof event.durationMs === "number"
      ? ` — ${(event.durationMs / 1000).toFixed(1)}s`
      : "";

  if (event.type === "attention_observation" && event.direction) {
    const label = DIRECTION_LABELS[event.direction] || `Looking ${event.direction}`;
    return `${label}${durationSuffix}`;
  }

  const label = TYPE_LABELS[event.type] || event.type.replace(/_/g, " ");
  return `${label}${durationSuffix}`;
}
