// api.js - thin wrapper around the backend REST API.

const API_URL = import.meta.env.VITE_API_URL || "http://localhost:5000";

async function handle(res) {
  const data = await res.json().catch(() => ({}));
  if (!res.ok) {
    throw new Error(data.error || `Request failed (${res.status})`);
  }
  return data;
}

export async function startInterview({ role, resumeText, resumeFile }) {
  const form = new FormData();
  form.append("role", role);
  if (resumeText) form.append("resumeText", resumeText);
  if (resumeFile) form.append("resumeFile", resumeFile);

  const res = await fetch(`${API_URL}/api/interview/start`, {
    method: "POST",
    body: form,
  });
  return handle(res);
}

export async function submitAnswer({ sessionId, answer }) {
  const res = await fetch(`${API_URL}/api/interview/answer`, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ sessionId, answer }),
  });
  return handle(res);
}

export async function finishInterview({ sessionId }) {
  const res = await fetch(`${API_URL}/api/interview/finish`, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ sessionId }),
  });
  return handle(res);
}

export async function logIntegrityEvent({ sessionId, ...event }) {
  // `event` carries at least `type`, plus whatever else CameraMonitor
  // attached (e.g. `detail`, and for attention_observation: `direction` /
  // `durationMs`) - forwarded through as-is rather than picked apart here,
  // so the frontend's event shape only has to be updated in one place.
  // Best-effort — never blocks or breaks the interview if this fails.
  try {
    await fetch(`${API_URL}/api/interview/integrity-event`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ sessionId, ...event }),
    });
  } catch (err) {
    console.warn("Failed to log integrity event:", err.message);
  }
}
