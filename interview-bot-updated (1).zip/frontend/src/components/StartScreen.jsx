// components/StartScreen.jsx — resume upload + job role selection.

import { useState } from "react";

const ROLE_OPTIONS = [
  "Frontend Engineer",
  "Backend Engineer",
  "Full-Stack Engineer",
  "Data Analyst / ML Engineer",
  "Other",
];

export default function StartScreen({ onStart, loading, error }) {
  const [role, setRole] = useState(ROLE_OPTIONS[0]);
  const [customRole, setCustomRole] = useState("");
  const [resumeText, setResumeText] = useState("");
  const [resumeFile, setResumeFile] = useState(null);

  const effectiveRole = role === "Other" ? customRole.trim() : role;
  const canSubmit = effectiveRole && (resumeText.trim() || resumeFile) && !loading;

  return (
    <div className="card">
      <h1>AI Interview Bot</h1>
      <p className="subtitle">
        Upload your resume, pick a target role, and start a personalized,
        adaptive mock interview.
      </p>

      <label className="field-label">Target role</label>
      <select value={role} onChange={(e) => setRole(e.target.value)}>
        {ROLE_OPTIONS.map((r) => (
          <option key={r} value={r}>
            {r}
          </option>
        ))}
      </select>
      {role === "Other" && (
        <input
          type="text"
          placeholder="e.g. DevOps Engineer"
          value={customRole}
          onChange={(e) => setCustomRole(e.target.value)}
        />
      )}

      <label className="field-label">Resume file (.pdf, .docx, .txt)</label>
      <input
        type="file"
        accept=".pdf,.docx,.txt"
        onChange={(e) => setResumeFile(e.target.files?.[0] || null)}
      />

      <label className="field-label">
        Or paste resume text {resumeFile ? "(optional extra context)" : ""}
      </label>
      <textarea
        rows={6}
        placeholder="Paste your resume text here..."
        value={resumeText}
        onChange={(e) => setResumeText(e.target.value)}
      />

      {error && <div className="error-banner">{error}</div>}

      <button
        className="primary-btn"
        disabled={!canSubmit}
        onClick={() => onStart({ role: effectiveRole, resumeText, resumeFile })}
      >
        {loading ? "Starting interview..." : "Start Interview"}
      </button>
    </div>
  );
}
