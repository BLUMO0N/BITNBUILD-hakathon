// components/CameraMonitor.jsx
//
// MILESTONE 5 (upgraded) — lightweight, local, client-side GAZE / ATTENTION
// ESTIMATION. This is NOT exact or medical-grade eye tracking - it is a
// coarse, smoothed estimate of where the candidate is roughly looking
// (center / left / right / up / down), used only to record neutral,
// timestamped observations. It never claims "cheating detected" and never
// makes a pass/fail judgment - that framing is intentional and unchanged
// from the original implementation.
//
// --- WHY MediaPipe FaceLandmarker (replacing face-api.js) -----------------
// The previous version used face-api.js's tiny face detector, which only
// gives a bounding box - no eyes, no iris, no head-pose. The task now
// explicitly needs iris position AND head orientation. face-api.js does
// ship a 68-point landmark model, but it has no iris landmarks at all and
// no built-in head-pose output (you'd have to hand-roll a solvePnP-style
// pose solve from the 68 points, which is a lot of fragile math to get
// right in a hackathon window). MediaPipe's FaceLandmarker (via the
// @mediapipe/tasks-vision package) gives 478 landmarks INCLUDING 10 iris
// points, runs fully client-side (WASM, nothing uploaded), and supports
// multi-face detection out of the box - so it's the better fit here, not
// just "more modern": it directly provides the two inputs the spec asks
// for (eye/iris landmarks + a usable head-orientation signal) that
// face-api.js cannot.
//
// One deliberate choice: MediaPipe also exposes a 4x4
// "facialTransformationMatrix" that can be decomposed into yaw/pitch. We
// intentionally do NOT use it for head orientation - its axis/sign
// convention is not guaranteed consistent across browsers/drivers/camera
// mirroring (documented real-world reports of it coming out inverted on
// some setups), which risks silently flipping "left"/"right" with no way
// to verify in this environment. Instead, head orientation here is
// estimated from plain 2D landmark geometry (nose-tip position relative to
// the eye-line/chin), which lives directly in the same frame-pixel space
// as everything else this file measures - unambiguous, and consistent
// with how the (unmirrored) preview is actually displayed.
//
// --- HOW GAZE IS ESTIMATED -------------------------------------------------
// Two signals are combined per the spec ("prefer combining eye movement and
// head pose instead of relying only on face-center position"):
//   1. Iris position within each eye socket (horizontal + vertical ratio),
//      averaged across both eyes.
//   2. A 2D head-orientation proxy: nose-tip position relative to the
//      eye-line/chin (yaw/pitch-ish, without needing 3D pose math).
// Both are measured relative to a short (~2s) per-session CALIBRATION
// baseline captured right after a face is first steadily detected, rather
// than fixed absolute thresholds - this is what lets it tolerate different
// faces, camera angles, and lighting instead of one hard-coded "center".
//
// --- FALSE-POSITIVE REDUCTION ---------------------------------------------
// - A blink guard (eye-openness ratio) skips a tick entirely during a
//   blink, rather than reading it as "looking down".
// - Every observation (face_not_detected / multiple_faces /
//   attention_observation) requires a run of consecutive confirming ticks,
//   not one noisy frame, AND respects a per-type cooldown so a sustained or
//   flickering condition can't spam repeated events. Returning to
//   center / a single face resets the relevant streak.
//
// --- PERFORMANCE ------------------------------------------------------------
// detectForVideo() is synchronous (it blocks until done), so checks can
// never literally overlap - but the loop still (a) throttles actual
// inference to a fixed interval via a requestAnimationFrame-driven clock
// rather than running every rendered frame, and (b) guards with a "busy"
// flag as a defensive safety net. This keeps it lightweight rather than a
// 60fps continuous tracker.

import { useEffect, useRef, useState } from "react";
import { FaceLandmarker, FilesetResolver } from "@mediapipe/tasks-vision";

// ---------------------------------------------------------------------------
// CONFIG - every tunable threshold lives here, in one place.
// ---------------------------------------------------------------------------

// Pinned to the same version as the npm dependency (see package.json) so the
// WASM runtime fetched from the CDN always matches the JS API we built
// against - a version mismatch between the two is a classic source of
// hard-to-debug MediaPipe failures.
const TASKS_VISION_VERSION = "0.10.22-rc.20250304";
const VISION_WASM_URL = `https://cdn.jsdelivr.net/npm/@mediapipe/tasks-vision@${TASKS_VISION_VERSION}/wasm`;
const MODEL_ASSET_URL =
  "https://storage.googleapis.com/mediapipe-models/face_landmarker/face_landmarker/float16/1/face_landmarker.task";

// Detect up to 3 faces so "2+ people in frame" is actually observable.
// Note: MediaPipe only applies its own internal temporal smoothing when
// numFaces is 1 - with multi-face support on, landmarks are naturally a bit
// jitterier frame-to-frame, which is exactly why this file does its own
// multi-frame smoothing (calibration averaging + consecutive-check
// confirmation) rather than trusting a single frame.
const MAX_FACES = 3;

// Throttle: run one detection pass at most this often (not every rAF tick).
const DETECTION_INTERVAL_MS = 400;
// face_not_detected / multiple_faces: consecutive ticks required (~1.2s).
const FACE_PRESENCE_CONSECUTIVE_THRESHOLD = 3;
// attention_observation: consecutive ticks required (~2.4s - "several
// seconds", per the spec's own example of what should/shouldn't fire).
const GAZE_CONSECUTIVE_THRESHOLD = 6;
// Once an observation type fires, don't fire that type again for this long.
const ALERT_COOLDOWN_MS = 20000;

// Calibration: average this many good (single face, not blinking) ticks
// right after start-up to learn this candidate/camera's "center", instead
// of assuming a fixed universal center.
const CALIBRATION_SAMPLE_COUNT = 5;

// Eye considered "closed enough to be a blink" when openness/width ratio
// drops below this - that tick is skipped rather than read as "looking
// down".
const BLINK_OPENNESS_RATIO_THRESHOLD = 0.15;

// How far (in normalized ratio units, roughly 0..1 within an eye socket or
// face span) a signal has to deviate from the calibrated baseline before
// it counts as "off-center". Demo-tuned, not empirically validated against
// a labeled dataset - kept here, centralized, so it's easy to retune.
const GAZE_H_THRESHOLD = 0.12;
const GAZE_V_THRESHOLD = 0.12;
// How much the head-orientation proxy contributes alongside the iris
// ratio when combining the two signals.
const HEAD_YAW_WEIGHT = 0.5;
const HEAD_PITCH_WEIGHT = 0.5;

// Landmark indices - MediaPipe FaceLandmarker's canonical 478-point face
// mesh (468 base points + 10 iris points added when iris refinement is
// active, which it is by default for this task). Eye "A"/"B" rather than
// anatomical left/right because we only need each eye's own socket-relative
// ratio, averaged - which physical eye is which doesn't matter here.
const EYE_A = { outer: 33, inner: 133, iris: 468, upperLid: 159, lowerLid: 145 };
const EYE_B = { outer: 263, inner: 362, iris: 473, upperLid: 386, lowerLid: 374 };
const NOSE_TIP = 4;
const CHIN = 152;

const DIRECTION_ARROWS = { center: "●", left: "←", right: "→", up: "↑", down: "↓", none: "—" };
const DIRECTION_TEXT = {
  center: "Looking at screen",
  left: "Looking left",
  right: "Looking right",
  up: "Looking up",
  down: "Looking down",
};

function clamp01(v) {
  return Math.min(1, Math.max(0, v));
}

// ---------------------------------------------------------------------------
// Pure-ish helpers (readable, single-purpose, per the spec's naming ask)
// ---------------------------------------------------------------------------

// Iris position within one eye's socket, as a 0..1 ratio (0.5 = centered).
function eyeHorizontalRatio(lm, eye) {
  const outerX = lm[eye.outer].x;
  const innerX = lm[eye.inner].x;
  const irisX = lm[eye.iris].x;
  const left = Math.min(outerX, innerX);
  const right = Math.max(outerX, innerX);
  const span = Math.max(right - left, 1e-6);
  return clamp01((irisX - left) / span);
}

// Estimates gaze inputs for a single face's landmark set. Returns null when
// a blink is detected this tick (caller should just skip the tick).
function estimateGaze(lm) {
  const widthA = Math.abs(lm[EYE_A.outer].x - lm[EYE_A.inner].x);
  const widthB = Math.abs(lm[EYE_B.outer].x - lm[EYE_B.inner].x);
  const opennessA = Math.max(lm[EYE_A.lowerLid].y - lm[EYE_A.upperLid].y, 1e-6);
  const opennessB = Math.max(lm[EYE_B.lowerLid].y - lm[EYE_B.upperLid].y, 1e-6);
  const opennessRatio =
    (opennessA / Math.max(widthA, 1e-6) + opennessB / Math.max(widthB, 1e-6)) / 2;

  if (opennessRatio < BLINK_OPENNESS_RATIO_THRESHOLD) {
    return null; // blink - tolerate it by skipping, not by reading it as "down"
  }

  const hA = eyeHorizontalRatio(lm, EYE_A);
  const hB = eyeHorizontalRatio(lm, EYE_B);
  const vA = clamp01((lm[EYE_A.iris].y - lm[EYE_A.upperLid].y) / opennessA);
  const vB = clamp01((lm[EYE_B.iris].y - lm[EYE_B.upperLid].y) / opennessB);

  // Head-orientation proxy (2D, frame-pixel-space - see file header for why
  // this is used instead of the transformation matrix).
  const leftX = Math.min(lm[EYE_A.outer].x, lm[EYE_B.outer].x);
  const rightX = Math.max(lm[EYE_A.outer].x, lm[EYE_B.outer].x);
  const spanX = Math.max(rightX - leftX, 1e-6);
  const noseYaw = (lm[NOSE_TIP].x - (leftX + rightX) / 2) / spanX;

  const eyeLineY =
    (lm[EYE_A.outer].y + lm[EYE_A.inner].y + lm[EYE_B.outer].y + lm[EYE_B.inner].y) / 4;
  const spanY = Math.max(lm[CHIN].y - eyeLineY, 1e-6);
  const nosePitch = (lm[NOSE_TIP].y - eyeLineY) / spanY;

  return { h: (hA + hB) / 2, v: (vA + vB) / 2, noseYaw, nosePitch };
}

// Classifies a calibrated gaze reading into center/left/right/up/down.
function classifyDirection(gaze, baseline) {
  const dH = gaze.h - baseline.h;
  const dV = gaze.v - baseline.v;
  const dNoseYaw = gaze.noseYaw - baseline.noseYaw;
  const dNosePitch = gaze.nosePitch - baseline.nosePitch;

  const combinedH = dH + HEAD_YAW_WEIGHT * dNoseYaw;
  const combinedV = dV + HEAD_PITCH_WEIGHT * dNosePitch;

  if (Math.abs(combinedH) >= Math.abs(combinedV) && Math.abs(combinedH) > GAZE_H_THRESHOLD) {
    return combinedH > 0 ? "right" : "left";
  }
  if (Math.abs(combinedV) > GAZE_V_THRESHOLD) {
    return combinedV > 0 ? "down" : "up";
  }
  return "center";
}

async function createFaceLandmarker() {
  const vision = await FilesetResolver.forVisionTasks(VISION_WASM_URL);
  const baseConfig = {
    runningMode: "VIDEO",
    numFaces: MAX_FACES,
    minFaceDetectionConfidence: 0.5,
    minFacePresenceConfidence: 0.5,
    minTrackingConfidence: 0.5,
  };
  try {
    return await FaceLandmarker.createFromOptions(vision, {
      ...baseConfig,
      baseOptions: { modelAssetPath: MODEL_ASSET_URL, delegate: "GPU" },
    });
  } catch (gpuErr) {
    console.warn("FaceLandmarker: GPU delegate failed, falling back to CPU:", gpuErr.message);
    return await FaceLandmarker.createFromOptions(vision, {
      ...baseConfig,
      baseOptions: { modelAssetPath: MODEL_ASSET_URL, delegate: "CPU" },
    });
  }
}

export default function CameraMonitor({ enabled, onEvent }) {
  const videoRef = useRef(null);
  const streamRef = useRef(null);
  const rafRef = useRef(null);
  const runningRef = useRef(false);
  const busyRef = useRef(false);
  const lastRunAtRef = useRef(0);
  const landmarkerRef = useRef(null);

  const noFaceStreakRef = useRef(0);
  const multiFaceStreakRef = useRef(0);
  const gazeStreakRef = useRef({ direction: "center", count: 0 });
  const calibrationRef = useRef({ h: [], v: [], noseYaw: [], nosePitch: [] });
  const baselineRef = useRef(null);
  const lastAlertAtRef = useRef({
    face_not_detected: 0,
    multiple_faces: 0,
    attention_observation: 0,
  });

  const [modelsReady, setModelsReady] = useState(false);
  const [cameraError, setCameraError] = useState(null);
  // Neutral, user-facing status only - never a verdict.
  const [status, setStatus] = useState({ kind: "info", text: "Loading vision model..." });
  const [panel, setPanel] = useState({
    faceLabel: "Detecting…",
    faceCount: 0,
    attentionLabel: "—",
    direction: "none",
  });

  // Load the vision model once. If this fails, camera monitoring simply
  // stays off - the interview itself never depends on it, and this never
  // gets stuck on a permanent "Loading..." state.
  useEffect(() => {
    let cancelled = false;
    createFaceLandmarker()
      .then((landmarker) => {
        if (cancelled) {
          landmarker.close?.();
          return;
        }
        landmarkerRef.current = landmarker;
        setModelsReady(true);
        setStatus({ kind: "ok", text: "Starting attention monitoring..." });
      })
      .catch((err) => {
        console.warn("Vision model failed to load:", err.message);
        if (!cancelled) {
          setModelsReady(false);
          setStatus({
            kind: "notice",
            text: "Attention monitoring unavailable (model failed to load). Interview continues normally.",
          });
        }
      });
    return () => {
      cancelled = true;
      landmarkerRef.current?.close?.();
      landmarkerRef.current = null;
    };
  }, []);

  // Start/stop camera based on `enabled`.
  useEffect(() => {
    if (!enabled) {
      stopCamera();
      return;
    }

    let cancelled = false;

    async function start() {
      try {
        const stream = await navigator.mediaDevices.getUserMedia({ video: true });
        if (cancelled) {
          stream.getTracks().forEach((t) => t.stop());
          return;
        }
        streamRef.current = stream;
        if (videoRef.current) {
          videoRef.current.srcObject = stream;
        }
        setCameraError(null);
      } catch (err) {
        setCameraError(
          "Camera unavailable or permission denied. Continuing in text-only mode."
        );
        onEvent({ type: "camera_unavailable", detail: err.message });
      }
    }

    start();

    return () => {
      cancelled = true;
      stopCamera();
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [enabled]);

  // Detection loop: only once the model is ready and the camera is on.
  // Driven by requestAnimationFrame (per MediaPipe's recommended pattern for
  // VIDEO mode) but gated to only actually run inference every
  // DETECTION_INTERVAL_MS, with a busy-flag guard so a slow pass can never
  // pile up work behind it.
  useEffect(() => {
    if (!enabled || !modelsReady || cameraError) return;

    runningRef.current = true;
    resetAll();
    lastRunAtRef.current = 0;

    function loop() {
      if (!runningRef.current) return;
      rafRef.current = requestAnimationFrame(loop);

      const now = performance.now();
      if (now - lastRunAtRef.current < DETECTION_INTERVAL_MS) return;
      if (busyRef.current) return;

      const video = videoRef.current;
      const landmarker = landmarkerRef.current;
      if (!video || video.readyState < 2 || !landmarker) return;

      lastRunAtRef.current = now;
      busyRef.current = true;
      try {
        const result = landmarker.detectForVideo(video, now);
        handleResult(result);
      } catch (err) {
        // Never let a detection hiccup break the interview - just skip
        // this check.
        console.warn("Face landmark detection check failed:", err.message);
      } finally {
        busyRef.current = false;
      }
    }

    rafRef.current = requestAnimationFrame(loop);

    return () => {
      runningRef.current = false;
      if (rafRef.current) cancelAnimationFrame(rafRef.current);
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [enabled, modelsReady, cameraError]);

  function resetAll() {
    noFaceStreakRef.current = 0;
    multiFaceStreakRef.current = 0;
    resetGazeAndCalibration();
  }

  function resetGazeAndCalibration() {
    gazeStreakRef.current = { direction: "center", count: 0 };
    baselineRef.current = null;
    calibrationRef.current = { h: [], v: [], noseYaw: [], nosePitch: [] };
  }

  // Fires onEvent once a streak crosses its threshold, but only if that
  // observation type isn't still in its cooldown window - this is what
  // stops a persistent (or flickering) condition from spamming repeated
  // alerts.
  function recordIntegrityEvent(type, extra) {
    const now = Date.now();
    const last = lastAlertAtRef.current[type] || 0;
    if (now - last < ALERT_COOLDOWN_MS) return;
    lastAlertAtRef.current[type] = now;
    onEvent({ type, ...extra });
  }

  function handleResult(result) {
    const faces = result?.faceLandmarks || [];
    const count = faces.length;

    if (count === 0) {
      noFaceStreakRef.current += 1;
      multiFaceStreakRef.current = 0;
      resetGazeAndCalibration();
      setStatus({ kind: "notice", text: "Face not detected" });
      setPanel({ faceLabel: "Not detected", faceCount: 0, attentionLabel: "—", direction: "none" });

      if (noFaceStreakRef.current === FACE_PRESENCE_CONSECUTIVE_THRESHOLD) {
        const durationMs = FACE_PRESENCE_CONSECUTIVE_THRESHOLD * DETECTION_INTERVAL_MS;
        recordIntegrityEvent("face_not_detected", {
          durationMs,
          detail: `No face detected for ~${(durationMs / 1000).toFixed(1)}s`,
        });
      }
      return;
    }

    if (count > 1) {
      multiFaceStreakRef.current += 1;
      noFaceStreakRef.current = 0;
      resetGazeAndCalibration();
      setStatus({ kind: "notice", text: `${count} faces in frame` });
      setPanel({ faceLabel: "Multiple", faceCount: count, attentionLabel: "—", direction: "none" });

      if (multiFaceStreakRef.current === FACE_PRESENCE_CONSECUTIVE_THRESHOLD) {
        recordIntegrityEvent("multiple_faces", {
          detail: `${count} faces detected in frame at the same time`,
        });
      }
      return;
    }

    // Exactly one face - the expected case.
    noFaceStreakRef.current = 0;
    multiFaceStreakRef.current = 0;

    const gaze = estimateGaze(faces[0]);
    if (!gaze) {
      // Blink - hold the previously shown status, skip this tick entirely.
      return;
    }

    if (!baselineRef.current) {
      runCalibrationTick(gaze);
      return;
    }

    const direction = classifyDirection(gaze, baselineRef.current);
    updateAttentionState(direction);
  }

  function runCalibrationTick(gaze) {
    const samples = calibrationRef.current;
    samples.h.push(gaze.h);
    samples.v.push(gaze.v);
    samples.noseYaw.push(gaze.noseYaw);
    samples.nosePitch.push(gaze.nosePitch);

    setStatus({
      kind: "info",
      text: `Calibrating attention monitoring... (${samples.h.length}/${CALIBRATION_SAMPLE_COUNT})`,
    });
    setPanel({ faceLabel: "Detected", faceCount: 1, attentionLabel: "Calibrating…", direction: "none" });

    if (samples.h.length >= CALIBRATION_SAMPLE_COUNT) {
      const avg = (arr) => arr.reduce((a, b) => a + b, 0) / arr.length;
      baselineRef.current = {
        h: avg(samples.h),
        v: avg(samples.v),
        noseYaw: avg(samples.noseYaw),
        nosePitch: avg(samples.nosePitch),
      };
      setStatus({ kind: "ok", text: "Attention monitoring active" });
    }
  }

  function updateAttentionState(direction) {
    const streak = gazeStreakRef.current;
    if (streak.direction === direction) {
      streak.count += 1;
    } else {
      streak.direction = direction;
      streak.count = 1;
    }

    if (direction === "center") {
      setStatus({ kind: "ok", text: "Looking at screen" });
      setPanel({ faceLabel: "Detected", faceCount: 1, attentionLabel: "Looking at screen", direction: "center" });
      return;
    }

    const label = DIRECTION_TEXT[direction];
    setStatus({ kind: "notice", text: label });
    setPanel({ faceLabel: "Detected", faceCount: 1, attentionLabel: label, direction });

    if (streak.count === GAZE_CONSECUTIVE_THRESHOLD) {
      const durationMs = streak.count * DETECTION_INTERVAL_MS;
      recordIntegrityEvent("attention_observation", {
        direction,
        durationMs,
        detail: `Looking ${direction} for ~${(durationMs / 1000).toFixed(1)}s`,
      });
    }
  }

  function stopCamera() {
    runningRef.current = false;
    if (rafRef.current) cancelAnimationFrame(rafRef.current);
    if (streamRef.current) {
      streamRef.current.getTracks().forEach((t) => t.stop());
      streamRef.current = null;
    }
  }

  if (!enabled) return null;

  const pillText = cameraError ? cameraError : status.text;
  const pillKind = cameraError ? "notice" : status.kind;
  const arrow = DIRECTION_ARROWS[panel.direction] || DIRECTION_ARROWS.none;

  return (
    <div className="camera-monitor">
      <div className="camera-preview-wrap">
        <video ref={videoRef} autoPlay muted playsInline className="camera-preview" />
        {!cameraError && modelsReady && (
          <div className={`gaze-indicator gaze-${panel.direction}`} title={panel.attentionLabel}>
            <span className="gaze-arrow">{arrow}</span>
          </div>
        )}
      </div>

      <div className="camera-status-panel">
        <div className="camera-status-row">
          <span>Face</span>
          <span>{panel.faceLabel}</span>
        </div>
        <div className="camera-status-row">
          <span>Faces</span>
          <span>{panel.faceCount}</span>
        </div>
        <div className="camera-status-row">
          <span>Attention</span>
          <span>{panel.attentionLabel}</span>
        </div>
      </div>

      <div className={`camera-pill camera-pill-${pillKind}`}>{pillText}</div>

      <p className="camera-disclaimer">
        Neutral observations only - not a verdict on the candidate.
      </p>
    </div>
  );
}
