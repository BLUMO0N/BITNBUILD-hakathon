// components/InterviewScreen.jsx — the live interview loop.

import { useEffect, useState } from "react";
import { useSpeech } from "../hooks/useSpeech.js";
import CameraMonitor from "./CameraMonitor.jsx";
import { submitAnswer, logIntegrityEvent } from "../api.js";
import { formatIntegrityEvent } from "../utils/integrityEvents.js";

// Live timeline is a rolling recent-history view, not a full audit log (the
// final report's list, sourced from the backend session, is the complete
// record) - so it's capped to keep the panel compact per the "keep this
// visually clean" instruction.
const MAX_TIMELINE_ENTRIES = 12;

export default function InterviewScreen({
  sessionId,
  question,
  questionNumber,
  maxQuestions,
  onAnswered,
}) {
  const speech = useSpeech();
  const [manualAnswer, setManualAnswer] = useState("");
  const [submitting, setSubmitting] = useState(false);
  const [error, setError] = useState(null);
  const [cameraOn, setCameraOn] = useState(true);
  const [lastFeedback, setLastFeedback] = useState(null);
  const [timeline, setTimeline] = useState([]);

  // Speak each new question aloud automatically.
  useEffect(() => {
    if (question && speech.supported) {
      speech.speak(question);
    }
    setManualAnswer("");
    speech.setTranscript("");
    setLastFeedback(null);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [question]);

  const answerText = speech.supported ? speech.transcript || manualAnswer : manualAnswer;

  async function handleSubmit() {
    const finalAnswer = answerText.trim();
    if (!finalAnswer) return;
    setSubmitting(true);
    setError(null);
    try {
      const result = await submitAnswer({ sessionId, answer: finalAnswer });
      setLastFeedback(result.lastEvaluation);
      onAnswered(result); // parent decides: advance to next question, or move to report
    } catch (err) {
      setError(err.message);
    } finally {
      setSubmitting(false);
    }
  }

  function handleIntegrityEvent(event) {
    logIntegrityEvent({ sessionId, ...event });
    setTimeline((prev) =>
      [{ ...event, timestamp: new Date().toISOString() }, ...prev].slice(0, MAX_TIMELINE_ENTRIES)
    );
  }

  const progressPct = Math.round((questionNumber / maxQuestions) * 100);

  return (
    <div className="interview-layout">
      <div className="card interview-main">
        <div className="interview-header-row">
          <h1 className="interview-title">AI Interview</h1>
          <span className="progress-label">
            Question {questionNumber} of {maxQuestions}
          </span>
        </div>
        <div className="progress-track" aria-hidden="true">
          <div className="progress-fill" style={{ width: `${progressPct}%` }} />
        </div>

        <h2 className="question-text">{question}</h2>

        {!speech.supported && (
          <div className="notice">
            Voice not supported in this browser — using text mode. (Try Chrome
            or Edge for spoken interviews.)
          </div>
        )}

        {speech.supported && (
          <div className="voice-controls">
            <button
              className={speech.isListening ? "mic-btn active" : "mic-btn"}
              onClick={speech.isListening ? speech.stopListening : speech.startListening}
            >
              {speech.isListening ? "Stop recording" : "Start speaking"}
            </button>
            {speech.isSpeaking && <span className="speaking-indicator">🔊 AI speaking...</span>}
          </div>
        )}

        <label className="field-label">Your answer</label>
        <textarea
          rows={5}
          placeholder="Speak or type your answer here..."
          value={speech.supported ? speech.transcript : manualAnswer}
          onChange={(e) =>
            speech.supported ? speech.setTranscript(e.target.value) : setManualAnswer(e.target.value)
          }
        />

        {/* Live interim preview only - never written into the answer box
            itself, so it can never duplicate/repeat words once finalized. */}
        {speech.supported && speech.isListening && speech.interimTranscript && (
          <div className="interim-preview">🎤 {speech.interimTranscript}</div>
        )}

        {lastFeedback && (
          <div className="feedback-note">
            Previous answer score: {lastFeedback.score}/10 — {lastFeedback.summary}
          </div>
        )}

        {error && <div className="error-banner">{error}</div>}

        <button
          className="primary-btn"
          disabled={!answerText.trim() || submitting}
          onClick={handleSubmit}
        >
          {submitting ? "Evaluating..." : "Submit Answer"}
        </button>
      </div>

      <div className="card integrity-panel">
        <div className="integrity-panel-header">
          <h3>Interview Integrity</h3>
          <label className="camera-toggle">
            <input
              type="checkbox"
              checked={cameraOn}
              onChange={(e) => setCameraOn(e.target.checked)}
            />
            Camera monitoring
          </label>
        </div>

        <CameraMonitor enabled={cameraOn} onEvent={handleIntegrityEvent} />

        {timeline.length > 0 && (
          <div className="integrity-timeline">
            <h4>Recent observations</h4>
            <ul>
              {timeline.map((e, i) => (
                <li key={i}>
                  <span className="timeline-time">
                    {new Date(e.timestamp).toLocaleTimeString()}
                  </span>
                  <span className="timeline-label">{formatIntegrityEvent(e)}</span>
                </li>
              ))}
            </ul>
          </div>
        )}
      </div>
    </div>
  );
}
