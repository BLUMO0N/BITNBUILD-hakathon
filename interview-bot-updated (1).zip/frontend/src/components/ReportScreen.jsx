// components/ReportScreen.jsx — final evaluation report.

import { formatIntegrityEvent } from "../utils/integrityEvents.js";

export default function ReportScreen({ report, integrityEvents, onRestart }) {
  if (!report) return null;

  return (
    <div className="card report-card">
      <h1>Interview Report</h1>

      <div className="score-badge">Overall score: {report.overallScore}/10</div>
      <div className="recommendation">{report.recommendation}</div>

      <section>
        <h3>Strengths</h3>
        <ul>
          {report.strengths?.map((s, i) => (
            <li key={i}>{s}</li>
          ))}
        </ul>
      </section>

      <section>
        <h3>Gaps / Areas to Improve</h3>
        <ul>
          {report.gaps?.map((g, i) => (
            <li key={i}>{g}</li>
          ))}
        </ul>
      </section>

      <section>
        <h3>Technical Evaluation</h3>
        <p>{report.technicalEvaluation}</p>
      </section>

      <section>
        <h3>Communication Observations</h3>
        <p>{report.communicationObservations}</p>
      </section>

      <section>
        <h3>Summary</h3>
        <p>{report.summary}</p>
      </section>

      {integrityEvents && integrityEvents.length > 0 && (
        <section>
          <h3>Attention / Integrity Observations</h3>
          <p className="notice">
            These are raw observations only — not proof of any wrongdoing.
          </p>
          <ul>
            {integrityEvents.map((e, i) => (
              <li key={i}>
                <span>{formatIntegrityEvent(e)}</span>{" "}
                <span className="timestamp">
                  ({new Date(e.timestamp).toLocaleTimeString()})
                </span>
              </li>
            ))}
          </ul>
        </section>
      )}

      <div className="disclaimer">{report.disclaimer}</div>

      <button className="primary-btn" onClick={onRestart}>
        Start Another Interview
      </button>
    </div>
  );
}
