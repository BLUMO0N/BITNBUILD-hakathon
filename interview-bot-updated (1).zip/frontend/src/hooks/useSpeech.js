// hooks/useSpeech.js
//
// IMPLEMENTATION CHOICE: the problem statement asks for Whisper (STT) and
// Piper (TTS). For a 6-hour hackathon those require bundling/running local
// model servers, which is heavy to set up and impossible to demo reliably
// on unfamiliar machines. Instead this uses the browser's built-in
// SpeechRecognition + SpeechSynthesis (Web Speech API), which gives the
// same user-facing capability — natural spoken interview, no server-side
// audio pipeline — with zero setup. It works best in Chrome/Edge.
// If the browser doesn't support it, the hook reports `supported: false`
// and the UI automatically falls back to the typed-answer flow, exactly
// as the spec's "keep text interview as a fallback" requirement asks.
//
// Swapping this hook for real Whisper/Piper calls later only requires
// changing this one file — the rest of the app just calls startListening/
// stopListening/speak.
//
// --- BUGFIX NOTES (repeated / duplicated words in the transcript) -------
// The previous onresult handler looped from `event.resultIndex` and
// appended whatever it found (final AND interim text alike) onto the
// *existing* transcript state, on every single onresult event. In
// continuous+interim mode, onresult fires repeatedly while a single
// phrase is still being recognized (each time with a longer interim
// guess), so the same words got appended again and again -> repeated /
// duplicated phrases, worse over longer answers with pauses.
//
// The fix:
//   1. Every onresult event rebuilds the transcript FROM SCRATCH by
//      reading the browser's own `event.results` list from index 0.
//      That list holds every result seen since the current .start()
//      call; each entry becomes final at most once and never changes
//      again after that. Rebuilding (instead of appending to prior
//      state) means the same finalized words can never be counted twice.
//   2. Final and interim text are kept as two SEPARATE pieces of state:
//        - `transcript`      -> committed, final text only. This is what
//                               gets shown in the editable answer box and
//                               what gets submitted.
//        - `interimTranscript` -> the live, not-yet-final guess. Shown
//                               separately as a preview only, and is
//                               NEVER written into `transcript`.
//   3. Starting a new recording resets both pieces of state, so
//      stopping and restarting always begins the current answer clean
//      instead of mixing old and new text together.
//   4. speak() and startListening() each stop the other side first, so
//      the question being read aloud (speech synthesis, played through
//      the speakers) is never picked up by an active microphone as part
//      of the candidate's answer.

import { useEffect, useRef, useState, useCallback } from "react";

export function useSpeech() {
  const [isListening, setIsListening] = useState(false);
  const [isSpeaking, setIsSpeaking] = useState(false);
  const [transcript, setTranscript] = useState(""); // committed/final text only
  const [interimTranscript, setInterimTranscript] = useState(""); // live preview only, never appended
  const [supported, setSupported] = useState(true);

  const recognitionRef = useRef(null);
  // Refs mirror the state above so callbacks (onresult/onend/speak/
  // startListening) always see the latest value instead of a stale
  // closure, without needing to recreate the recognition object.
  const isListeningRef = useRef(false);
  const isSpeakingRef = useRef(false);
  const interimRef = useRef("");

  useEffect(() => {
    const SpeechRecognition =
      window.SpeechRecognition || window.webkitSpeechRecognition;

    if (!SpeechRecognition || !window.speechSynthesis) {
      setSupported(false);
      return;
    }

    const recognition = new SpeechRecognition();
    recognition.continuous = true;
    recognition.interimResults = true;
    recognition.lang = "en-US";

    recognition.onresult = (event) => {
      // Rebuild fully from event.results every time (see notes above) -
      // this is what prevents repeated / duplicated words. Each
      // finalized result covers one pause-delimited phrase; they're
      // joined with a single space (rather than raw-concatenated) so a
      // multi-sentence answer with pauses reads naturally instead of
      // sentences running into each other.
      const finalChunks = [];
      const interimChunks = [];
      for (let i = 0; i < event.results.length; i++) {
        const result = event.results[i];
        const text = result[0] ? result[0].transcript.trim() : "";
        if (!text) continue;
        if (result.isFinal) {
          finalChunks.push(text);
        } else {
          interimChunks.push(text);
        }
      }
      const finalText = finalChunks.join(" ");
      const interimText = interimChunks.join(" ");
      setTranscript(finalText);
      setInterimTranscript(interimText);
      interimRef.current = interimText;
    };

    recognition.onerror = (event) => {
      console.warn("Speech recognition error:", event.error);
      // Some errors (permission revoked, no mic) don't reliably fire
      // onend afterwards in every browser - make sure the UI doesn't
      // get stuck showing "listening" forever.
      if (
        event.error === "not-allowed" ||
        event.error === "service-not-allowed" ||
        event.error === "audio-capture"
      ) {
        setIsListening(false);
        isListeningRef.current = false;
      }
    };

    recognition.onend = () => {
      setIsListening(false);
      isListeningRef.current = false;
      // Safety net: if recognition stopped while some interim text was
      // still "in flight" and never got a final result (e.g. the user
      // clicked stop mid-word), fold it into the committed transcript
      // instead of silently losing those words.
      if (interimRef.current) {
        const leftover = interimRef.current;
        interimRef.current = "";
        setInterimTranscript("");
        setTranscript((prev) => (prev ? `${prev} ${leftover}` : leftover));
      }
    };

    recognitionRef.current = recognition;

    return () => {
      recognition.onresult = null;
      recognition.onerror = null;
      recognition.onend = null;
      recognition.stop();
    };
  }, []);

  const startListening = useCallback(() => {
    if (!recognitionRef.current) return;

    // Don't let the mic pick up the question being read aloud: if TTS
    // is still talking when the user hits "start speaking", cut it off
    // first.
    if (isSpeakingRef.current && window.speechSynthesis) {
      window.speechSynthesis.cancel();
      setIsSpeaking(false);
      isSpeakingRef.current = false;
    }

    // Restarting recording always begins the current answer clean.
    setTranscript("");
    setInterimTranscript("");
    interimRef.current = "";

    try {
      recognitionRef.current.start();
      setIsListening(true);
      isListeningRef.current = true;
    } catch (err) {
      // start() throws if it's already running - safe to ignore, we're
      // already listening in that case.
    }
  }, []);

  const stopListening = useCallback(() => {
    if (!recognitionRef.current) return;
    recognitionRef.current.stop();
    setIsListening(false);
    isListeningRef.current = false;
  }, []);

  const speak = useCallback((text) => {
    if (!window.speechSynthesis) return;

    // Don't let an active mic capture the question being read aloud:
    // stop listening first if recording is in progress.
    if (isListeningRef.current && recognitionRef.current) {
      recognitionRef.current.stop();
      setIsListening(false);
      isListeningRef.current = false;
    }

    window.speechSynthesis.cancel();
    const utterance = new SpeechSynthesisUtterance(text);
    utterance.rate = 1;
    utterance.onstart = () => {
      setIsSpeaking(true);
      isSpeakingRef.current = true;
    };
    utterance.onend = () => {
      setIsSpeaking(false);
      isSpeakingRef.current = false;
    };
    utterance.onerror = () => {
      setIsSpeaking(false);
      isSpeakingRef.current = false;
    };
    window.speechSynthesis.speak(utterance);
  }, []);

  return {
    supported,
    isListening,
    isSpeaking,
    transcript,
    interimTranscript,
    setTranscript,
    startListening,
    stopListening,
    speak,
  };
}
