import { useState } from "react";
import StartScreen from "./components/StartScreen.jsx";
import InterviewScreen from "./components/InterviewScreen.jsx";
import ReportScreen from "./components/ReportScreen.jsx";
import { startInterview, finishInterview } from "./api.js";

// screen: 'start' | 'interview' | 'report'
export default function App() {
  const [screen, setScreen] = useState("start");
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState(null);

  const [sessionId, setSessionId] = useState(null);
  const [question, setQuestion] = useState(null);
  const [questionNumber, setQuestionNumber] = useState(1);
  const [maxQuestions, setMaxQuestions] = useState(5);

  const [report, setReport] = useState(null);
  const [integrityEvents, setIntegrityEvents] = useState([]);

  async function handleStart({ role, resumeText, resumeFile }) {
    setLoading(true);
    setError(null);
    try {
      const result = await startInterview({ role, resumeText, resumeFile });
      setSessionId(result.sessionId);
      setQuestion(result.question);
      setQuestionNumber(result.questionNumber);
      setMaxQuestions(result.maxQuestions);
      setScreen("interview");
    } catch (err) {
      setError(err.message);
    } finally {
      setLoading(false);
    }
  }

  async function handleAnswered(result) {
    if (result.done) {
      try {
        const finishResult = await finishInterview({ sessionId });
        setReport(finishResult.report);
        setIntegrityEvents(finishResult.integrityEvents || []);
        setScreen("report");
      } catch (err) {
        setError(err.message);
      }
    } else {
      setQuestion(result.question);
      setQuestionNumber(result.questionNumber);
    }
  }

  function handleRestart() {
    setScreen("start");
    setSessionId(null);
    setQuestion(null);
    setQuestionNumber(1);
    setReport(null);
    setIntegrityEvents([]);
    setError(null);
  }

  return (
    <div className="app-shell">
      {screen === "start" && (
        <StartScreen onStart={handleStart} loading={loading} error={error} />
      )}
      {screen === "interview" && (
        <InterviewScreen
          sessionId={sessionId}
          question={question}
          questionNumber={questionNumber}
          maxQuestions={maxQuestions}
          onAnswered={handleAnswered}
        />
      )}
      {screen === "report" && (
        <ReportScreen
          report={report}
          integrityEvents={integrityEvents}
          onRestart={handleRestart}
        />
      )}
    </div>
  );
}
