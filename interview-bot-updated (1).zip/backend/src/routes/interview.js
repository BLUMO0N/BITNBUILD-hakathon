// routes/interview.js
// REST API for the interview flow. Kept as three endpoints matching the
// three milestones, plus one small endpoint for integrity/attention events.

import express from "express";
import multer from "multer";
import { v4 as uuidv4 } from "uuid";
import { askOllamaJSON } from "../services/ollama.js";
import {
  buildStartPrompt,
  buildAnswerPrompt,
  buildReportPrompt,
} from "../services/prompts.js";
import {
  createSession,
  getSession,
  updateSession,
  addIntegrityEvent,
} from "../services/sessionStore.js";
import { extractResumeText } from "../services/resumeParser.js";
import {
  persistSessionStart,
  persistQuestionAnswer,
  persistReport,
  persistIntegrityEvent,
  markSessionCompleted,
} from "../services/supabase.js";

const router = express.Router();
const upload = multer({ storage: multer.memoryStorage() });

const MAX_QUESTIONS = parseInt(process.env.MAX_QUESTIONS || "5", 10);

/**
 * MILESTONE 1
 * POST /api/interview/start
 * multipart/form-data:
 *   - resumeFile (optional file: pdf/docx/txt)
 *   - resumeText (optional string, used if no file uploaded / as extra context)
 *   - role (required string)
 *
 * Response: { sessionId, candidateProfile, question, difficulty, questionNumber, maxQuestions }
 */
router.post("/start", upload.single("resumeFile"), async (req, res) => {
  try {
    const role = (req.body.role || "").trim();
    if (!role) {
      return res.status(400).json({ error: "role is required" });
    }

    let resumeText = (req.body.resumeText || "").trim();
    if (req.file) {
      const fileText = await extractResumeText(req.file);
      resumeText = [resumeText, fileText].filter(Boolean).join("\n\n");
    }

    if (!resumeText) {
      return res
        .status(400)
        .json({ error: "resumeText or resumeFile is required" });
    }

    const prompt = buildStartPrompt(resumeText, role);
    const result = await askOllamaJSON(prompt);

    if (!result.firstQuestion || !result.candidateProfile) {
      throw new Error("Model response missing required fields");
    }

    const sessionId = uuidv4();
    const session = createSession({
      sessionId,
      role,
      resumeText,
      candidateProfile: result.candidateProfile,
    });

    session.currentQuestion = result.firstQuestion;
    session.currentDifficulty = result.difficulty || "medium";
    session.questionNumber = 1;
    updateSession(sessionId, session);

    persistSessionStart(session); // fire-and-forget, safe no-op if unconfigured

    return res.json({
      sessionId,
      candidateProfile: session.candidateProfile,
      question: session.currentQuestion,
      difficulty: session.currentDifficulty,
      questionNumber: session.questionNumber,
      maxQuestions: MAX_QUESTIONS,
    });
  } catch (err) {
    console.error("[/start] error:", err.message);
    return res.status(500).json({ error: err.message });
  }
});

/**
 * MILESTONE 2
 * POST /api/interview/answer
 * JSON body: { sessionId, answer }
 *
 * Response: either
 *   { done: false, question, difficulty, questionNumber, maxQuestions, lastEvaluation }
 * or
 *   { done: true, lastEvaluation }  (frontend should then call /finish)
 */
router.post("/answer", express.json(), async (req, res) => {
  try {
    const { sessionId, answer } = req.body;
    if (!sessionId || !answer) {
      return res.status(400).json({ error: "sessionId and answer are required" });
    }

    const session = getSession(sessionId);
    if (!session) {
      return res.status(404).json({ error: "session not found" });
    }
    if (session.status === "completed") {
      return res.status(400).json({ error: "interview already completed" });
    }

    const prompt = buildAnswerPrompt({
      role: session.role,
      candidateProfile: session.candidateProfile,
      history: session.history,
      currentQuestion: session.currentQuestion,
      candidateAnswer: answer,
      questionNumber: session.questionNumber,
      maxQuestions: MAX_QUESTIONS,
    });

    const result = await askOllamaJSON(prompt);

    const entry = {
      question: session.currentQuestion,
      answer,
      evaluation: result.evaluation,
    };
    session.history.push(entry);
    persistQuestionAnswer(sessionId, session.questionNumber, entry);

    const isComplete =
      Boolean(result.isInterviewComplete) || session.questionNumber >= MAX_QUESTIONS;

    if (isComplete) {
      session.status = "ready_for_report";
      session.currentQuestion = null;
      updateSession(sessionId, session);
      return res.json({ done: true, lastEvaluation: result.evaluation });
    }

    session.currentQuestion = result.nextQuestion;
    session.currentDifficulty = result.nextDifficulty || session.currentDifficulty;
    session.questionNumber += 1;
    updateSession(sessionId, session);

    return res.json({
      done: false,
      question: session.currentQuestion,
      difficulty: session.currentDifficulty,
      questionNumber: session.questionNumber,
      maxQuestions: MAX_QUESTIONS,
      lastEvaluation: result.evaluation,
    });
  } catch (err) {
    console.error("[/answer] error:", err.message);
    return res.status(500).json({ error: err.message });
  }
});

/**
 * MILESTONE 3
 * POST /api/interview/finish
 * JSON body: { sessionId }
 *
 * Response: { report, integrityEvents }
 */
router.post("/finish", express.json(), async (req, res) => {
  try {
    const { sessionId } = req.body;
    if (!sessionId) {
      return res.status(400).json({ error: "sessionId is required" });
    }

    const session = getSession(sessionId);
    if (!session) {
      return res.status(404).json({ error: "session not found" });
    }
    if (session.history.length === 0) {
      return res
        .status(400)
        .json({ error: "cannot generate a report with no answered questions" });
    }

    const prompt = buildReportPrompt({
      role: session.role,
      candidateProfile: session.candidateProfile,
      history: session.history,
    });

    const report = await askOllamaJSON(prompt);

    session.status = "completed";
    session.report = report;
    updateSession(sessionId, session);

    persistReport(sessionId, report);
    markSessionCompleted(sessionId);

    return res.json({
      report,
      integrityEvents: session.integrityEvents,
    });
  } catch (err) {
    console.error("[/finish] error:", err.message);
    return res.status(500).json({ error: err.message });
  }
});

/**
 * MILESTONE 5
 * POST /api/interview/integrity-event
 * JSON body: { sessionId, type, detail, direction?, durationMs? }
 * type examples: 'face_not_detected', 'multiple_faces', 'attention_observation', 'camera_unavailable'
 * direction (only for 'attention_observation'): 'left' | 'right' | 'up' | 'down'
 * This only ever RECORDS observations. It never labels or scores them.
 */
router.post("/integrity-event", express.json(), async (req, res) => {
  try {
    const { sessionId, type, detail, direction, durationMs } = req.body;
    if (!sessionId || !type) {
      return res.status(400).json({ error: "sessionId and type are required" });
    }
    // direction/durationMs are kept in-memory (and returned to the frontend
    // via /finish) so the report can show them structured. Supabase
    // persistence intentionally keeps its existing type/detail/occurred_at
    // shape unchanged - the schema wasn't touched for this change, and
    // `detail` already carries this same information as neutral text.
    const session = addIntegrityEvent(sessionId, { type, detail, direction, durationMs });
    if (!session) {
      return res.status(404).json({ error: "session not found" });
    }
    persistIntegrityEvent(sessionId, {
      type,
      detail,
      timestamp: new Date().toISOString(),
    });
    return res.json({ ok: true });
  } catch (err) {
    console.error("[/integrity-event] error:", err.message);
    return res.status(500).json({ error: err.message });
  }
});

export default router;
