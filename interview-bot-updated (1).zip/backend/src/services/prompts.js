// services/prompts.js
// All prompt templates in one place so Developer 3 (AI/prompt logic) can
// tune them without touching route or service code.

export function buildStartPrompt(resumeText, role) {
  return `You are an expert technical interviewer preparing for a live interview.

CANDIDATE RESUME:
"""
${resumeText}
"""

TARGET ROLE: ${role}

TASK:
1. Read the resume and extract a concise candidate profile relevant to the target role.
2. Generate ONE strong opening interview question, personalized to this candidate and role.
   - Prefer a question that connects something specific in the resume to the target role.
   - Keep it open-ended, not yes/no.

Respond with ONLY a JSON object in exactly this shape, no extra text:
{
  "candidateProfile": {
    "name": "string or null if not found",
    "yearsOfExperience": "string, best estimate, e.g. '2 years' or 'fresher'",
    "keySkills": ["string", "..."],
    "notableProjects": ["short string", "..."],
    "summary": "2-3 sentence summary of the candidate relative to the target role"
  },
  "firstQuestion": "string",
  "difficulty": "easy | medium | hard"
}`;
}

export function buildAnswerPrompt({
  role,
  candidateProfile,
  history,
  currentQuestion,
  candidateAnswer,
  questionNumber,
  maxQuestions,
}) {
  const historyText = history
    .map(
      (h, i) =>
        `Q${i + 1}: ${h.question}\nA${i + 1}: ${h.answer}\nEvaluation: ${
          h.evaluation?.summary || "n/a"
        }`
    )
    .join("\n\n");

  const isLast = questionNumber >= maxQuestions;

  return `You are an expert technical interviewer conducting a live, adaptive interview.

TARGET ROLE: ${role}
CANDIDATE PROFILE: ${JSON.stringify(candidateProfile)}

INTERVIEW SO FAR:
${historyText || "(no previous questions)"}

CURRENT QUESTION: ${currentQuestion}
CANDIDATE'S ANSWER: """${candidateAnswer}"""

This is question ${questionNumber} of ${maxQuestions}.

TASK:
1. Evaluate the candidate's answer: identify strengths and weaknesses, and rate it.
2. Decide the direction and difficulty for the next question based on how they performed
   (go deeper if they did well, pivot or simplify if they struggled, avoid repeating topics).
3. ${
    isLast
      ? "This was the FINAL question. Do NOT generate another question — set nextQuestion to null and isInterviewComplete to true."
      : "Generate the next personalized interview question."
  }

Respond with ONLY a JSON object in exactly this shape, no extra text:
{
  "evaluation": {
    "score": "number from 1-10",
    "strengths": ["string", "..."],
    "weaknesses": ["string", "..."],
    "summary": "1-2 sentence evaluation of this specific answer"
  },
  "nextQuestion": ${isLast ? "null" : '"string"'},
  "nextDifficulty": ${isLast ? "null" : '"easy | medium | hard"'},
  "isInterviewComplete": ${isLast ? "true" : "false"}
}`;
}

export function buildReportPrompt({ role, candidateProfile, history }) {
  const historyText = history
    .map(
      (h, i) =>
        `Q${i + 1}: ${h.question}\nA${i + 1}: ${h.answer}\nScore: ${
          h.evaluation?.score ?? "n/a"
        }\nEvaluation notes: ${h.evaluation?.summary || "n/a"}`
    )
    .join("\n\n");

  return `You are an expert technical interviewer writing a final candidate report.

TARGET ROLE: ${role}
CANDIDATE PROFILE: ${JSON.stringify(candidateProfile)}

FULL INTERVIEW TRANSCRIPT AND PER-QUESTION EVALUATIONS:
${historyText}

TASK:
Write a final, balanced interview report. Be specific and evidence-based — reference
what the candidate actually said. Do NOT present this as a final hiring decision; it is
input for a human reviewer.

Respond with ONLY a JSON object in exactly this shape, no extra text:
{
  "overallScore": "number from 1-10",
  "strengths": ["string", "..."],
  "gaps": ["string", "..."],
  "technicalEvaluation": "2-4 sentences on role-related/technical competence",
  "communicationObservations": "1-3 sentences on clarity/communication, based only on what was observed",
  "summary": "3-5 sentence overall summary",
  "recommendation": "one of: 'Strong fit', 'Potential fit with gaps', 'Not a clear fit', 'Insufficient evidence'",
  "disclaimer": "This is AI-generated interview feedback intended to support, not replace, human hiring judgment."
}`;
}
