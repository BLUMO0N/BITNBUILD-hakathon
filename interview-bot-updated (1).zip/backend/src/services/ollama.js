// services/ollama.js
// Thin wrapper around a local Ollama instance. All AI reasoning (resume
// understanding, question generation, answer evaluation, adaptive next
// question, final report) is delegated to the model through this module.

const OLLAMA_URL = process.env.OLLAMA_URL || "http://localhost:11434";
const OLLAMA_MODEL = process.env.OLLAMA_MODEL || "qwen3:8b";

/**
 * Calls Ollama's /api/generate endpoint and forces JSON-mode output so the
 * rest of the app can rely on structured data instead of parsing prose.
 *
 * @param {string} prompt - full prompt (system + task instructions inlined)
 * @returns {Promise<object>} parsed JSON object from the model
 */
export async function askOllamaJSON(prompt) {
  const res = await fetch(`${OLLAMA_URL}/api/generate`, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({
      model: OLLAMA_MODEL,
      prompt,
      format: "json", // Ollama JSON mode - guarantees syntactically valid JSON
      stream: false,
      options: {
        temperature: 0.4,
      },
    }),
  });

  if (!res.ok) {
    const text = await res.text().catch(() => "");
    throw new Error(
      `Ollama request failed (${res.status}): ${text || res.statusText}`
    );
  }

  const data = await res.json();
  const raw = data.response ?? "";

  return safeParseJSON(raw);
}

/**
 * qwen3 sometimes wraps its <think> reasoning or code fences around the
 * JSON even in JSON mode. This strips common wrappers before parsing, and
 * falls back to extracting the first {...} block if needed.
 */
function safeParseJSON(raw) {
  let text = String(raw).trim();

  // Strip <think>...</think> blocks some Qwen models emit
  text = text.replace(/<think>[\s\S]*?<\/think>/gi, "").trim();

  // Strip markdown code fences if present
  text = text.replace(/^```json\s*/i, "").replace(/^```\s*/i, "");
  text = text.replace(/```\s*$/i, "").trim();

  try {
    return JSON.parse(text);
  } catch (err) {
    // Fallback: grab the first {...} block in the text
    const match = text.match(/\{[\s\S]*\}/);
    if (match) {
      try {
        return JSON.parse(match[0]);
      } catch (err2) {
        throw new Error(
          `Model did not return valid JSON. Raw output: ${text.slice(0, 500)}`
        );
      }
    }
    throw new Error(
      `Model did not return valid JSON. Raw output: ${text.slice(0, 500)}`
    );
  }
}

export async function checkOllamaHealth() {
  try {
    const res = await fetch(`${OLLAMA_URL}/api/tags`);
    if (!res.ok) return { ok: false, error: `status ${res.status}` };
    const data = await res.json();
    const models = (data.models || []).map((m) => m.name);
    return { ok: true, models, targetModel: OLLAMA_MODEL };
  } catch (err) {
    return { ok: false, error: err.message };
  }
}
