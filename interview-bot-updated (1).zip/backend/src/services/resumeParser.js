// services/resumeParser.js
// Extracts plain text from an uploaded resume file (pdf, docx, or txt).
// Kept intentionally simple: no OCR, no layout parsing — just enough to
// hand clean text to the model.

import pdfParse from "pdf-parse";
import mammoth from "mammoth";

export async function extractResumeText(file) {
  if (!file) return "";

  const { originalname, buffer, mimetype } = file;
  const name = (originalname || "").toLowerCase();

  try {
    if (mimetype === "application/pdf" || name.endsWith(".pdf")) {
      const data = await pdfParse(buffer);
      return data.text.trim();
    }

    if (
      mimetype ===
        "application/vnd.openxmlformats-officedocument.wordprocessingml.document" ||
      name.endsWith(".docx")
    ) {
      const result = await mammoth.extractRawText({ buffer });
      return result.value.trim();
    }

    // Fallback: treat as plain text
    return buffer.toString("utf-8").trim();
  } catch (err) {
    throw new Error(`Could not read resume file: ${err.message}`);
  }
}
