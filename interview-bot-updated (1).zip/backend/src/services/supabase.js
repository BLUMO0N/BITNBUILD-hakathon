// services/supabase.js
// Optional persistence layer. If SUPABASE_URL / SUPABASE_SERVICE_KEY are not
// set, every function here becomes a safe no-op so the interview flow keeps
// working purely in-memory (see sessionStore.js). This lets Milestones 1-5
// be built and demoed without ever touching Supabase, and Milestone 6 only
// has to fill in real credentials to switch persistence on.

import { createClient } from "@supabase/supabase-js";

const SUPABASE_URL = process.env.SUPABASE_URL;
const SUPABASE_SERVICE_KEY = process.env.SUPABASE_SERVICE_KEY;

export const isSupabaseConfigured = Boolean(SUPABASE_URL && SUPABASE_SERVICE_KEY);

export const supabase = isSupabaseConfigured
  ? createClient(SUPABASE_URL, SUPABASE_SERVICE_KEY)
  : null;

async function safe(label, fn) {
  if (!isSupabaseConfigured) return { skipped: true };
  try {
    const { error, data } = await fn();
    if (error) {
      console.error(`[supabase] ${label} error:`, error.message);
      return { error };
    }
    return { data };
  } catch (err) {
    console.error(`[supabase] ${label} threw:`, err.message);
    return { error: err };
  }
}

export function persistSessionStart(session) {
  return safe("persistSessionStart", () =>
    supabase.from("sessions").insert({
      id: session.sessionId,
      role: session.role,
      candidate_profile: session.candidateProfile,
      status: session.status,
      created_at: session.createdAt,
    })
  );
}

export function persistQuestionAnswer(sessionId, questionNumber, entry) {
  return safe("persistQuestionAnswer", () =>
    supabase.from("questions_answers").insert({
      session_id: sessionId,
      question_number: questionNumber,
      question: entry.question,
      answer: entry.answer,
      evaluation: entry.evaluation,
    })
  );
}

export function persistReport(sessionId, report) {
  return safe("persistReport", () =>
    supabase.from("reports").insert({
      session_id: sessionId,
      report,
    })
  );
}

export function persistIntegrityEvent(sessionId, event) {
  return safe("persistIntegrityEvent", () =>
    supabase.from("integrity_events").insert({
      session_id: sessionId,
      type: event.type,
      detail: event.detail || null,
      occurred_at: event.timestamp,
    })
  );
}

export function markSessionCompleted(sessionId) {
  return safe("markSessionCompleted", () =>
    supabase.from("sessions").update({ status: "completed" }).eq("id", sessionId)
  );
}
