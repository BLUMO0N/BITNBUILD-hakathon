-- Supabase schema for the AI Interview Bot (Milestone 6)
-- Run this in the Supabase SQL editor for your project.

create table if not exists sessions (
  id text primary key,
  role text not null,
  candidate_profile jsonb,
  status text default 'in_progress',
  created_at timestamptz default now()
);

create table if not exists questions_answers (
  id bigint generated always as identity primary key,
  session_id text references sessions(id) on delete cascade,
  question_number int not null,
  question text not null,
  answer text,
  evaluation jsonb,
  created_at timestamptz default now()
);

create table if not exists reports (
  id bigint generated always as identity primary key,
  session_id text references sessions(id) on delete cascade,
  report jsonb not null,
  created_at timestamptz default now()
);

create table if not exists integrity_events (
  id bigint generated always as identity primary key,
  session_id text references sessions(id) on delete cascade,
  type text not null,       -- e.g. 'face_not_detected', 'looking_away', 'camera_disabled'
  detail text,
  occurred_at timestamptz default now()
);

-- Helpful indexes
create index if not exists idx_qa_session on questions_answers(session_id);
create index if not exists idx_events_session on integrity_events(session_id);
