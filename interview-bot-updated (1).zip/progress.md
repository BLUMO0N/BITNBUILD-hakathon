# Progress

## Milestone 1 — Backend + Ollama connection (`POST /api/interview/start`) — ✅ DONE
- Express server (`backend/src/server.js`) with health check at `/api/health`.
- `POST /api/interview/start` accepts a resume (file upload: pdf/docx/txt, or pasted text)
  and a target role, calls Ollama (`qwen3:8b`, JSON mode) to extract a candidate profile
  and generate the first personalized question.
- Tested end-to-end against a mock Ollama server (real network calls, real JSON parsing,
  real session creation) — see "How it was tested" in the root README.

## Milestone 2 — Adaptive loop (`POST /api/interview/answer`) — ✅ DONE
- Evaluates the candidate's answer (score, strengths, weaknesses).
- Generates the next question and difficulty based on performance so far.
- Signals `isInterviewComplete` once `MAX_QUESTIONS` (default 5, configurable via `.env`) is reached.
- Tested end-to-end (start → answer → next question loop).

## Milestone 3 — Final report (`POST /api/interview/finish`) — ✅ DONE
- Generates a structured report: overall score, strengths, gaps, technical evaluation,
  communication observations, summary, recommendation, and an explicit disclaimer that
  this supports (not replaces) human hiring judgment.
- Tested end-to-end.

## Milestone 4 — Voice interaction — ✅ DONE (implementation choice noted)
- Spoken interview via the browser's Web Speech API (SpeechRecognition for STT,
  SpeechSynthesis for TTS) instead of self-hosted Whisper/Piper — zero setup, works
  instantly in Chrome/Edge, same user-facing capability. See `frontend/src/hooks/useSpeech.js`
  for the reasoning; swapping in real Whisper/Piper later only touches that one file.
- Automatic fallback to typed answers if the browser doesn't support the Web Speech API,
  or if the user just prefers to type.

## Milestone 5 — Camera / attention observation — ✅ DONE
- `frontend/src/components/CameraMonitor.jsx` uses face-api.js's tiny face detector
  (a small pretrained model, bundled in `frontend/public/models`, runs entirely
  client-side — nothing is uploaded).
- Logs only neutral, timestamped observations: `face_not_detected`, `multiple_faces`,
  `attention_observation`, `camera_unavailable`. Never labels anything as "cheating."
- `POST /api/interview/integrity-event` records these; they're surfaced transparently
  on the final report screen, tested end-to-end.

## Milestone 5 — upgraded to gaze / head-orientation attention estimation
- Replaced face-api.js's tiny face detector with MediaPipe's `FaceLandmarker`
  (`@mediapipe/tasks-vision`), loaded client-side (WASM + model fetched from
  Google's CDN at runtime — nothing is uploaded, and the interview never
  depends on this load succeeding; see "Known limitations" in the README).
  face-api.js has no iris landmarks and no head-pose output, which the task
  now explicitly requires; MediaPipe gives 478 landmarks (including 10 iris
  points) and supports multiple simultaneous faces natively.
- `CameraMonitor.jsx` now estimates gaze as CENTER / LEFT / RIGHT / UP / DOWN
  by combining (a) iris position within each eye socket and (b) a 2D
  head-orientation proxy (nose-tip position relative to the eye-line/chin),
  both measured against a short (~2s) per-session calibration baseline
  rather than fixed absolute thresholds. A blink guard (eye-openness ratio)
  skips a tick entirely during a blink instead of reading it as "looking
  down". Deliberately does NOT use MediaPipe's 4x4 facial-transformation
  matrix for head pose — its sign convention isn't guaranteed consistent
  across browsers/cameras, whereas the 2D approach stays in the same
  frame-pixel space as everything else here.
- Same false-positive protections as before, generalized to gaze direction:
  a run of consecutive confirming ticks (not one noisy frame) before firing,
  plus a per-type cooldown so a sustained or flickering condition can't spam
  repeated events. `attention_observation` events now carry a `direction`
  and `durationMs` field (in addition to the existing neutral `detail`
  string), shown live during the interview (new right-hand "Interview
  Integrity" panel) and in the final report.
- Detection is driven by `requestAnimationFrame` (MediaPipe's recommended
  pattern for VIDEO mode) but throttled to a fixed interval with a busy-flag
  guard, so a slow pass still can't pile up work.
- All thresholds (interval, consecutive-check counts, cooldown, calibration
  sample count, blink/gaze thresholds, head-orientation signal weights) are
  centralized as named constants at the top of `CameraMonitor.jsx`.

## Post-hackathon fixes (see summary below)
- **Speech transcription repetition fixed.** `useSpeech.js`'s onresult handler was
  appending every result (final + interim) onto the existing transcript on every
  event, causing repeated/duplicated words in continuous mode. Now rebuilds the
  transcript from `event.results` each time and keeps final vs. interim text as
  separate state, so nothing gets double-counted.
- **Camera monitoring upgraded.** `CameraMonitor.jsx` now uses `detectAllFaces()`
  (was `detectSingleFace()`, which could never see a second person), requires a
  short run of consecutive confirming checks before logging anything (was
  effectively single-frame-triggered for "looking away"), and adds a cooldown so a
  persistent or flickering condition can't spam repeated alerts. `looking_away` was
  renamed to `attention_observation` and a new `multiple_faces` observation was
  added, matching the neutral-observation framing above. The detection loop is
  self-scheduling (setTimeout chained after each check) instead of a bare
  `setInterval`, so slow checks can't overlap and pile up.

## Milestone 6 — Supabase persistence + full connection — ✅ DONE (persistence optional)
- `backend/src/supabase/schema.sql` defines `sessions`, `questions_answers`, `reports`,
  `integrity_events` tables.
- `backend/src/services/supabase.js` writes to these tables whenever `SUPABASE_URL` and
  `SUPABASE_SERVICE_KEY` are set in `.env`. If they're not set, every call is a safe
  no-op — the whole app (Milestones 1–5) works fully in-memory with zero Supabase setup,
  exactly per the "don't build unnecessary complexity" instruction.
- Frontend and backend are fully wired end-to-end (see root README "Run it" section).

## What's left / nice-to-haves if there's time left in the hackathon
- Add a mananged chunk split for the frontend build (face-api.js pushes the bundle over
  Vite's default 500kB warning threshold — cosmetic only, not a functional issue).
- Add automated tests (currently verified via manual + mock-Ollama end-to-end curl tests).
- Optional: swap Web Speech API for real local Whisper/Piper if the judges specifically
  require fully offline/on-device audio processing.
