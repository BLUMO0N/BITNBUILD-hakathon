# AI-Powered Interview Bot

6-hour hackathon build. Frontend (React) + Backend (Node/Express) + local
Ollama (`qwen3:8b`) for all interview reasoning, browser-native voice, and
client-side attention monitoring.

See `progress.md` for exactly what's implemented per milestone and every
implementation choice made where the problem statement was ambiguous.

## Prerequisites

- Node.js 18+ and npm
- [Ollama](https://ollama.com) installed and running locally, with the model already pulled:
  ```
  ollama pull qwen3:8b
  ollama serve   # usually already running as a background service
  ```
- Chrome or Edge recommended (for the Web Speech API — see Milestone 4 note in `progress.md`).
- Optional: a [Supabase](https://supabase.com) project if you want persistence
  (otherwise everything runs fine in-memory).

## 1. Backend setup

```bash
cd backend
npm install
cp .env.example .env
# edit .env if your Ollama runs elsewhere, or to add Supabase credentials
npm start
```

This starts the API on `http://localhost:5000`. Check it's talking to Ollama:

```bash
curl http://localhost:5000/api/health
```

You should see `"ollama": { "ok": true, "models": ["qwen3:8b", ...] }`.

### Optional: enable Supabase persistence

1. Create a Supabase project.
2. Run `backend/src/supabase/schema.sql` in the Supabase SQL editor.
3. Put your project URL and service-role key into `backend/.env`
   (`SUPABASE_URL`, `SUPABASE_SERVICE_KEY`).
4. Restart the backend. `/api/health` will report `"supabaseConfigured": true`.

## 2. Frontend setup

```bash
cd frontend
npm install
cp .env.example .env   # only needed if backend isn't on localhost:5000
npm run dev
```

Open the printed URL (typically `http://localhost:5173`).

## 3. Using the app

1. **Start screen**: pick a target role, upload a resume (pdf/docx/txt) or paste resume text.
2. **Interview screen**: the question is read aloud automatically. Click "Start speaking"
   to answer by voice (or just type in the box). Submit each answer to get the next,
   adaptively generated question. A small camera preview (optional, toggle-able) silently
   logs attention observations — it never blocks or judges you, just records timestamps.
3. **Report screen**: strengths, gaps, technical evaluation, communication notes, an overall
   recommendation, and any attention observations gathered — with a clear disclaimer that
   this is feedback to support (not replace) a human decision.

## How the backend was tested

Because Ollama itself can't run inside the environment this was built in, the full
`/start → /answer → /integrity-event → /finish` flow was tested end-to-end against a
minimal mock server that mimics Ollama's `/api/generate` and `/api/tags` endpoints —
i.e. every line of real backend code (JSON-mode parsing, session state, adaptive question
selection, integrity event logging, Supabase no-op fallback) ran and was verified; only the
model's "brain" was swapped for a stub. Point `OLLAMA_URL` at your real local Ollama and it
works the same way, with real model reasoning instead of the stub's canned answers.

The frontend was verified with `npm run build` (clean production build, no errors).
Voice and camera features depend on browser APIs and hardware permissions that can only
be exercised in an actual browser session on your machine — test those live after `npm run dev`.

## Project structure

```
backend/
  src/
    server.js              Express app entrypoint, health check
    routes/interview.js    /start, /answer, /finish, /integrity-event
    services/ollama.js     Ollama client (JSON mode + robust parsing)
    services/prompts.js    All prompt templates (tune here)
    services/sessionStore.js  In-memory interview session state
    services/supabase.js   Optional persistence (safe no-op if unconfigured)
    services/resumeParser.js  pdf/docx/txt text extraction
    supabase/schema.sql    Table definitions for Milestone 6
frontend/
  src/
    App.jsx                Screen routing (start → interview → report)
    api.js                 Backend API client
    hooks/useSpeech.js      Web Speech API STT/TTS wrapper (Milestone 4)
    components/
      StartScreen.jsx       Resume upload + role selection
      InterviewScreen.jsx    Live interview loop
      CameraMonitor.jsx      MediaPipe FaceLandmarker gaze/attention estimation (Milestone 5)
      ReportScreen.jsx       Final report display
    utils/integrityEvents.js  Shared neutral-language formatter for integrity events
  public/models/            Unused leftover from the earlier face-api.js version (safe to delete)
progress.md                 Milestone-by-milestone status
```

### Known limitations (attention monitoring)

- This is gaze/attention **estimation**, not exact or medical-grade eye
  tracking — it's a coarse, smoothed signal meant to support a human
  reviewer, not to make an automated judgment.
- The vision model (MediaPipe FaceLandmarker) is loaded from a CDN
  (jsdelivr + Google's model storage) the first time the interview screen
  opens, so it needs internet access once per session — if that fetch
  fails, camera monitoring is disabled but the interview itself is
  unaffected (see the "Attention monitoring unavailable" status).
- Calibration happens once, a couple of seconds into each interview,
  assuming the candidate starts out looking at the screen. A large camera/
  seating change afterwards could shift what the system treats as
  "center" for the rest of that session.
- Multi-face detection requires MediaPipe's `numFaces` option to be greater
  than 1, which disables its own internal single-face landmark smoothing —
  compensated here by this file's own multi-frame smoothing (calibration
  averaging + consecutive-check confirmation), but landmarks may still be
  slightly jitterier than a single-face-only configuration would be.
